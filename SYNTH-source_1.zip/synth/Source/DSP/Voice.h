#pragma once
#include "Dsp.h"
#include "../Params.h"

namespace synth
{
struct Global
{
    double bpm = 120.0;
    float bend = 0.0f;        // -1..1
    float modWheel = 0.0f;    // 0..1
    float aftertouch = 0.0f;  // 0..1
};

class Voice
{
public:
    static constexpr int MAX_UNI = 7;
    static constexpr int CTRL = 16;

    void prepare(double sampleRate, uint32_t seed);
    void noteOn(int note, float velocity, float startNote, bool retrigger, uint64_t age);
    void retarget(int note);               // legato: change pitch without retrigger
    void noteOff();
    void kill();
    bool isActive() const { return amp.st != dsp::Adsr::Idle; }
    bool isReleasing() const { return amp.st == dsp::Adsr::Release; }
    bool gateOn() const { return amp.st != dsp::Adsr::Idle && amp.st != dsp::Adsr::Release; }
    float level() const { return amp.v; }
    uint64_t age = 0;
    int note = -1;
    bool sustained = false;               // held by the sustain pedal

    // adds into L / R
    void render(float* L, float* R, int n, const float* p, const Global& g);

private:
    void control(int blk, const float* p, const Global& g);

    float sr = 44100.0f;
    dsp::Rng rng{1234u};
    float velocity = 1.0f, targetNote = 60.0f, curNote = 60.0f, noteRand = 0.0f;
    float phase[2][MAX_UNI] = {};
    float subPhase = 0.0f;
    dsp::Adsr amp, env2;
    dsp::Lfo lfo[2];
    dsp::FilterUnit f1, f2;
    dsp::OnePole noiseLp;
    // drift state
    float driftP = 0, driftPT = 0, driftC = 0, driftCT = 0; int driftCount = 0;

    // per control-block values
    float inc[2][MAX_UNI] = {}, gL[2][MAX_UNI] = {}, gR[2][MAX_UNI] = {};
    int uni[2] = { 1, 1 }; float uniNorm[2] = { 1, 1 };
    int lvl[2] = { 0, 0 }; float tpos[2] = { 0, 0 };
    float level1 = 0, level2 = 0, subLevel = 0, subInc = 0, noiseLevel = 0, fmAmt = 0, ringAmt = 0;
    float ampGain = 0, ampGainT = 0, panL = 1, panR = 1, panLT = 1, panRT = 1;
    int f1Type = 1, f2Mode = 0, subWave = 0;
    float dt = 1.0f / 44100.0f;
    static float readTable(int t0, int t1, float frac, int level, float ph);
};
}
