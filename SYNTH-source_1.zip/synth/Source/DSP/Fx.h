#pragma once
#include "Dsp.h"
#include "../Params.h"
#include <array>

namespace synth
{
// Pitch shifter (octave up) used inside the reverb for shimmer
struct OctaveUp
{
    dsp::DelayLine line; float ph = 0; int window = 2048;
    void init(int win) { window = win; line.init(win * 2 + 8); ph = 0; }
    float process(float x)
    {
        line.write(x);
        const float W = (float) window;
        ph += 1.0f; if (ph >= W) ph -= W;
        const float p2 = std::fmod(ph + W * 0.5f, W);
        const float w1 = std::sin(dsp::PI * ph / W), w2 = std::sin(dsp::PI * p2 / W);
        return line.read(W - ph + 1.0f) * w1 * w1 + line.read(W - p2 + 1.0f) * w2 * w2;
    }
};

class Reverb
{
public:
    static constexpr int N = 8;
    void prepare(double sr);
    void reset();
    // size/decay/damp 0..1, pre in ms
    void process(float& l, float& r, float size, float decay, float damp, float preMs, float shimmer, float mix);
private:
    float sr = 44100.0f;
    dsp::DelayLine lines[N], pre[2];
    float lp[N] = {};
    float lfoPh[N] = {};
    float lenCache[N] = {}, gainCache[N] = {}, cachedSz = -1.0f, cachedRt = -1.0f;
    OctaveUp shift;
    dsp::DCBlock dc[2];
    float shimState = 0;
    dsp::Smooth sizeS;
};

class FxChain
{
public:
    void prepare(double sampleRate);
    void reset();
    void process(float* L, float* R, int n, const float* p, double bpm);
private:
    float sr = 44100.0f;
    // distortion
    dsp::DCBlock dcL, dcR; dsp::Smooth distMix, distDrive;
    // crush
    float holdL = 0, holdR = 0, crushCount = 0; dsp::Smooth crushMix;
    // chorus
    dsp::DelayLine choL, choR; float choPh = 0; dsp::Smooth choMix;
    // tape
    dsp::DelayLine tapeL, tapeR; float wowPh = 0, flutPh = 0; dsp::OnePole tapeLpL, tapeLpR, hissLp;
    float crackle = 0; dsp::Rng rng{4242u}; dsp::Smooth tapeAmt, tapeNoise;
    // delay
    dsp::DelayLine dlyL, dlyR; dsp::Smooth dlyTime, dlyMix; dsp::OnePole dlyLpL, dlyLpR, dlyHpL, dlyHpR;
    // reverb
    Reverb reverb; dsp::Smooth revMix;
    // underwater / master
    dsp::SVF uwL, uwR; dsp::Smooth uwCut, master, width;
    float limGain = 1.0f;
};
}
