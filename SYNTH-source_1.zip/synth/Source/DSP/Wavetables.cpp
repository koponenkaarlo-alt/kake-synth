#include "Wavetables.h"
#include <cmath>
#include <vector>
#include <mutex>
#include <cstdint>
#include <algorithm>

namespace wt
{
namespace
{
constexpr int MAXH = 1024;
std::vector<float> g_data; // NUM_TABLES * NUM_LEVELS * (SIZE+1)
std::once_flag g_once;
}
const float* g_tableBase = nullptr;
namespace
{

const char* kNames[NUM_TABLES] = { "Soft Sine", "Glass Bell", "Choir Ahh", "Hollow Flute", "Super Saw", "Digital Pluck",
                                   "Dark Reese", "Rage Saw", "Lo-Fi Square", "Metal", "Vinyl Dust", "Vocal Oh" };

struct Spectrum { float amp[MAXH + 1]; int phase[MAXH + 1]; }; // phase in table steps 0..SIZE-1

uint32_t rngState = 12345;
float rnd() { rngState = rngState * 1664525u + 1013904223u; return (rngState >> 8) * (1.0f / 16777216.0f); }

bool isPrime(int n) { if (n < 2) return false; for (int i = 2; i * i <= n; ++i) if (n % i == 0) return false; return true; }
float gauss(float x, float c, float w) { float d = (x - c) / w; return std::exp(-d * d); }

void buildSpectrum(int t, Spectrum& s)
{
    rngState = 9001u + (uint32_t) t * 7919u;
    for (int k = 0; k <= MAXH; ++k) { s.amp[k] = 0; s.phase[k] = 0; }
    for (int k = 1; k <= MAXH; ++k)
    {
        float a = 0; const float fk = (float) k;
        switch (t)
        {
            case 0: a = (k == 1) ? 1.0f : (k == 2 ? 0.18f : (k == 3 ? 0.08f : (k <= 6 ? 0.02f : 0))); break;
            case 1: { const int keep[] = { 1, 4, 5, 7, 10, 12, 15, 19, 23 };
                      for (int q : keep)
                          if (q == k)
                              a = std::exp(-fk / 14.0f) / std::sqrt(fk) * 1.4f;
                      break; }
            case 2: a = (1.0f / fk) * (0.15f + 1.2f * gauss(fk, 6, 1.6f) + 0.9f * gauss(fk, 9, 1.8f) + 0.5f * gauss(fk, 22, 3.0f)); break;
            case 3: a = (k & 1) ? 1.0f / std::pow(fk, 1.5f) : (k == 2 ? 0.05f : 0); break;
            case 4: a = 1.0f / fk; break;
            case 5: a = (1.0f / fk) * (0.45f + 0.55f * std::cos(fk * 0.7f)); break;
            case 6: a = (1.0f / fk) * std::exp(-fk / 22.0f); s.phase[k] = (int) (rnd() * SIZE * 0.35f); break;
            case 7: a = std::pow(fk, -0.7f) * (1.0f + 1.6f * gauss(fk, 12, 3.0f)); break;
            case 8: a = (k & 1) ? (1.0f / fk) * std::exp(-fk / 40.0f) : 0; break;
            case 9: a = isPrime(k) ? 1.0f / std::sqrt(fk) : 0.04f / std::sqrt(fk); break;
            case 10: a = std::pow(fk, -0.8f) * (0.25f + rnd()); s.phase[k] = (int) (rnd() * SIZE); break;
            case 11: a = (1.0f / fk) * (0.1f + 1.3f * gauss(fk, 4, 1.2f) + 0.8f * gauss(fk, 7, 1.4f)); break;
        }
        s.amp[k] = a;
    }
}
}

void init()
{
    std::call_once(g_once, []
    {
        g_data.assign((size_t) NUM_TABLES * NUM_LEVELS * (SIZE + 1), 0.0f);
        std::vector<float> sine(SIZE);
        for (int i = 0; i < SIZE; ++i) sine[i] = (float) std::sin(2.0 * 3.14159265358979323846 * i / SIZE);

        for (int t = 0; t < NUM_TABLES; ++t)
        {
            Spectrum sp; buildSpectrum(t, sp);
            float scale = 1.0f;
            for (int l = 0; l < NUM_LEVELS; ++l)
            {
                float* out = g_data.data() + ((size_t) t * NUM_LEVELS + l) * (SIZE + 1);
                const int H = std::max(1, MAXH >> l);
                for (int i = 0; i < SIZE; ++i)
                {
                    float acc = 0;
                    for (int k = 1; k <= H; ++k)
                        if (sp.amp[k] != 0.0f) acc += sp.amp[k] * sine[(k * i + sp.phase[k]) & (SIZE - 1)];
                    out[i] = acc;
                }
                if (l == 0)
                {   // loudness-normalise all tables on level 0 RMS, cap the peak
                    double sum = 0; float peak = 1e-9f;
                    for (int i = 0; i < SIZE; ++i) { sum += out[i] * out[i]; peak = std::max(peak, std::fabs(out[i])); }
                    const float rms = (float) std::sqrt(sum / SIZE);
                    scale = 0.32f / std::max(rms, 1e-6f);
                    if (peak * scale > 0.95f) scale = 0.95f / peak;
                }
                for (int i = 0; i < SIZE; ++i) out[i] *= scale;
                out[SIZE] = out[0];
            }
        }
        g_tableBase = g_data.data();
    });
}

const float* table(int t, int level)
{
    init();
    t = std::clamp(t, 0, NUM_TABLES - 1); level = std::clamp(level, 0, NUM_LEVELS - 1);
    return g_data.data() + ((size_t) t * NUM_LEVELS + level) * (SIZE + 1);
}

const char* name(int t) { return kNames[std::clamp(t, 0, NUM_TABLES - 1)]; }

int levelForHarmonics(float maxH)
{
    if (maxH >= (float) MAXH) return 0;
    if (maxH <= 1.0f) return NUM_LEVELS - 1;
    const int l = (int) std::ceil(std::log2((float) MAXH / maxH));
    return std::clamp(l, 0, NUM_LEVELS - 1);
}
}
