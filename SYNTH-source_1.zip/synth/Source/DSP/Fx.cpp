#include "Fx.h"
#include <cmath>

using namespace dsp;
using namespace synthp;

namespace synth
{
// ---------------------------------------------------------------- Reverb
static const int kLen[Reverb::N] = { 1117, 1327, 1559, 1787, 1997, 2251, 2503, 2777 };

void Reverb::prepare(double sampleRate)
{
    sr = (float) sampleRate;
    const float scale = sr / 48000.0f;
    for (int i = 0; i < N; ++i) { lines[i].init((int) (kLen[i] * scale * 2.4f) + 64); lfoPh[i] = (float) i / (float) N; }
    pre[0].init((int) (sr * 0.25f)); pre[1].init((int) (sr * 0.25f));
    shift.init((int) (sr * 0.05f));
    sizeS.setTime(0.15f, sr);
    reset();
}

void Reverb::reset()
{
    for (auto& l : lines) l.clear();
    pre[0].clear(); pre[1].clear();
    for (float& v : lp) v = 0;
    shimState = 0; shift.line.clear();
}

void Reverb::process(float& l, float& r, float size, float decay, float damp, float preMs, float shimmer, float mix)
{
    const float sz = sizeS.next(0.5f + size * 1.5f);
    const float scale = sr / 48000.0f;
    const float rt60 = 0.3f * std::pow(60.0f, decay);
    const float dampC = 0.08f + (1.0f - damp) * 0.85f; // lowpass coefficient (lower = darker)

    pre[0].write(l); pre[1].write(r);
    const float inL = pre[0].read(preMs * 0.001f * sr + 1.0f), inR = pre[1].read(preMs * 0.001f * sr + 1.0f);

    if (std::fabs(sz - cachedSz) > 1.0e-4f || std::fabs(rt60 - cachedRt) > 1.0e-4f)
    {
        cachedSz = sz; cachedRt = rt60;
        for (int i = 0; i < N; ++i) { lenCache[i] = (float) kLen[i] * scale * sz; gainCache[i] = std::pow(10.0f, -3.0f * lenCache[i] / (rt60 * sr)); }
    }
    float v[N];
    for (int i = 0; i < N; ++i)
    {
        lfoPh[i] += (0.1f + 0.03f * (float) i) / sr; if (lfoPh[i] > 1.0f) lfoPh[i] -= 1.0f;
        const float mod = fastSinCycles(lfoPh[i]) * 6.0f * scale;
        v[i] = lines[i].read(lenCache[i] + mod);
        lp[i] += dampC * (v[i] - lp[i]);
        v[i] = lp[i] * gainCache[i];
    }
    // Hadamard mix (8x8)
    for (int s = 1; s < N; s <<= 1)
        for (int i = 0; i < N; i += s * 2)
            for (int j = i; j < i + s; ++j) { const float a = v[j], b = v[j + s]; v[j] = a + b; v[j + s] = a - b; }
    const float norm = 0.35355339f;

    // shimmer: octave-up of the wet signal fed back
    const float shimIn = (shimmer > 0.001f) ? fastTanh(shift.process(shimState)) * shimmer * 0.32f : 0.0f;

    float outL = 0, outR = 0;
    for (int i = 0; i < N; ++i)
    {
        const float in = ((i & 1) ? inR : inL) * 0.5f + shimIn;
        float x = v[i] * norm + in;
        lines[i].write(fastTanh(x));
        if (i & 1) outR += (i & 2 ? -1.0f : 1.0f) * v[i]; else outL += (i & 2 ? -1.0f : 1.0f) * v[i];
    }
    outL *= 0.35f; outR *= 0.35f;
    shimState = 0.5f * (outL + outR);
    outL = dc[0].process(outL); outR = dc[1].process(outR);
    l = l * (1.0f - mix * 0.35f) + outL * mix * 1.1f;
    r = r * (1.0f - mix * 0.35f) + outR * mix * 1.1f;
}

// ---------------------------------------------------------------- FxChain
static const float kDlyBeats[8] = { 0.0f, 1.0f, 1.5f, 0.5f, 0.75f, 1.0f / 3.0f, 0.25f, 2.0f };

void FxChain::prepare(double sampleRate)
{
    sr = (float) sampleRate;
    for (Smooth* s : { &distMix, &distDrive, &crushMix, &choMix, &tapeAmt, &tapeNoise, &dlyMix, &revMix, &master, &width })
        s->setTime(0.02f, sr);
    dlyTime.setTime(0.12f, sr); uwCut.setTime(0.05f, sr);
    choL.init((int) (sr * 0.05f)); choR.init((int) (sr * 0.05f));
    tapeL.init((int) (sr * 0.03f)); tapeR.init((int) (sr * 0.03f));
    dlyL.init((int) (sr * 3.2f)); dlyR.init((int) (sr * 3.2f));
    reverb.prepare(sampleRate);
    hissLp.setCutoff(5000.0f, sr);
    reset();
}

void FxChain::reset()
{
    for (auto* d : { &choL, &choR, &tapeL, &tapeR, &dlyL, &dlyR }) d->clear();
    reverb.reset(); uwL.reset(); uwR.reset(); limGain = 1.0f; holdL = holdR = 0;
}

static inline float distort(float x, int type, float drive)
{
    const float g = 1.0f + drive * 24.0f;
    x *= g;
    switch (type)
    {
        case 1: return clampf(x, -1.0f, 1.0f) * 0.8f;
        case 2: { float y = x; for (int i = 0; i < 3 && std::fabs(y) > 1.0f; ++i) y = (y > 1.0f) ? 2.0f - y : (y < -1.0f ? -2.0f - y : y); return clampf(y, -1.0f, 1.0f) * 0.8f; }
        default: return fastTanh(x) * 0.9f;
    }
}

void FxChain::process(float* L, float* R, int n, const float* p, double bpm)
{
    const int dType = (int) (p[DIST_TYPE] + 0.5f);
    const float bits = std::round(p[CRUSH_BITS]);
    const float levels = std::exp2(bits - 1.0f);
    const float rateDiv = p[CRUSH_RATE];
    const float choRate = p[CHO_RATE], choDepth = p[CHO_DEPTH];
    const float tapeTone = p[TAPE_TONE];
    tapeLpL.setCutoff(tapeTone, sr); tapeLpR.setCutoff(tapeTone, sr);
    const int div = (int) (p[DLY_DIV] + 0.5f);
    const float dlyMs = (div == 0) ? p[DLY_TIME] : (float) (60000.0 / std::max(20.0, bpm)) * kDlyBeats[div];
    const float dlyFb = p[DLY_FB];
    dlyLpL.setCutoff(p[DLY_TONE], sr); dlyLpR.setCutoff(p[DLY_TONE], sr);
    dlyHpL.setCutoff(140.0f, sr); dlyHpR.setCutoff(140.0f, sr);

    bool bad = false;
    for (int i = 0; i < n; ++i)
    {
        float l = L[i], r = R[i];

        // distortion
        const float dm = distMix.next(p[DIST_MIX]);
        if (dm > 0.0005f)
        {
            const float dr = distDrive.next(p[DIST_DRIVE]);
            const float wl = dcL.process(distort(l, dType, dr)), wr = dcR.process(distort(r, dType, dr));
            l = lerp(l, wl, dm); r = lerp(r, wr, dm);
        }
        // bitcrush / sample-rate reduction
        const float cm = crushMix.next(p[CRUSH_MIX]);
        if (cm > 0.0005f)
        {
            crushCount += 1.0f;
            if (crushCount >= rateDiv) { crushCount -= rateDiv; holdL = std::round(l * levels) / levels; holdR = std::round(r * levels) / levels; }
            l = lerp(l, holdL, cm); r = lerp(r, holdR, cm);
        }
        // chorus / ensemble
        const float chm = choMix.next(p[CHO_MIX]);
        choL.write(l); choR.write(r);
        if (chm > 0.0005f)
        {
            choPh += choRate / sr; if (choPh >= 1.0f) choPh -= 1.0f;
            const float depth = choDepth * 0.006f * sr, base = 0.012f * sr;
            const float a = std::sin(TWO_PI * choPh), b = std::sin(TWO_PI * (choPh + 0.333f)), c = std::sin(TWO_PI * (choPh + 0.667f));
            const float wl = 0.5f * (choL.read(base + depth * a) + choL.read(base * 1.3f + depth * c));
            const float wr = 0.5f * (choR.read(base + depth * b) + choR.read(base * 1.3f + depth * a));
            l = lerp(l, wl * 1.1f, chm * 0.8f); r = lerp(r, wr * 1.1f, chm * 0.8f);
        }
        // tape: wow/flutter, saturation, high-cut, hiss + crackle
        const float ta = tapeAmt.next(p[TAPE_AMT]);
        const float tn = tapeNoise.next(p[TAPE_NOISE]);
        if (ta > 0.0005f || tn > 0.0005f)
        {
            tapeL.write(l); tapeR.write(r);
            wowPh += 0.55f / sr; if (wowPh >= 1.0f) wowPh -= 1.0f;
            flutPh += 6.3f / sr; if (flutPh >= 1.0f) flutPh -= 1.0f;
            const float wow = std::sin(TWO_PI * wowPh), wow2 = std::sin(TWO_PI * (wowPh * 1.37f + 0.2f));
            const float fl = std::sin(TWO_PI * flutPh);
            const float base = 0.008f * sr, dw = ta * 0.0016f * sr, df = ta * 0.00012f * sr;
            float wl = tapeL.read(base + dw * wow + df * fl);
            float wr = tapeR.read(base + dw * wow2 + df * fl * 0.8f);
            const float sg = 1.0f + ta * 2.5f;
            wl = fastTanh(wl * sg) / std::sqrt(sg); wr = fastTanh(wr * sg) / std::sqrt(sg);
            wl = tapeLpL.lp(wl); wr = tapeLpR.lp(wr);
            l = lerp(l, wl, std::min(1.0f, ta * 4.0f)); r = lerp(r, wr, std::min(1.0f, ta * 4.0f));
            if (tn > 0.0005f)
            {
                const float hiss = hissLp.lp(rng.bi()) * tn * 0.05f;
                if (rng.uni() < (0.00008f + 0.0006f * tn) * (44100.0f / sr)) crackle = (rng.bi() > 0 ? 1.0f : -1.0f) * (0.02f + rng.uni() * 0.1f) * tn;
                crackle *= 0.85f;
                l += hiss + crackle; r += hiss * 0.9f + crackle * 0.7f;
            }
        }
        // ping-pong delay
        const float dmix = dlyMix.next(p[DLY_MIX]);
        {
            const float dTime = dlyTime.next(dlyMs) * 0.001f * sr;
            const float eL = dlyL.read(dTime), eR = dlyR.read(dTime);
            float fbL = dlyLpL.lp(eL); fbL -= dlyHpL.lp(fbL);
            float fbR = dlyLpR.lp(eR); fbR -= dlyHpR.lp(fbR);
            const float inM = 0.5f * (l + r);
            dlyL.write(fastTanh(inM * 0.8f + fbR * dlyFb));
            dlyR.write(fastTanh(fbL * dlyFb));
            l += eL * dmix; r += eR * dmix;
        }
        // reverb
        const float rm = revMix.next(p[REV_MIX]);
        if (rm > 0.0005f || p[REV_SHIM] > 0.001f) reverb.process(l, r, p[REV_SIZE], p[REV_DECAY], p[REV_DAMP], p[REV_PRE], p[REV_SHIM], rm);

        // underwater low-pass
        const float uc = uwCut.next(p[UW_CUT]);
        if (uc < 19000.0f)
        {
            if ((i & 15) == 0) { uwL.set(uc, 0.75f, sr); uwR = uwL; }
            float lp, bp, hp;
            uwL.tick(l, lp, bp, hp); l = lp; uwR.tick(r, lp, bp, hp); r = lp;
        }
        // master: volume + width
        const float mv = master.next(p[MASTER_VOL]); const float w = width.next(p[MASTER_WIDTH]);
        const float mid = 0.5f * (l + r), side = 0.5f * (l - r) * w;
        l = (mid + side) * mv * 1.05f; r = (mid - side) * mv * 1.05f;

        // safety limiter (instant attack, smooth release) + soft clip
        const float peak = std::max(std::fabs(l), std::fabs(r));
        const float thr = 0.92f;
        const float target = peak > thr ? thr / peak : 1.0f;
        if (target < limGain) limGain = target; else limGain += (target - limGain) * (1.0f / (0.08f * sr));
        l *= limGain; r *= limGain;
        L[i] = clampf(l, -0.999f, 0.999f); R[i] = clampf(r, -0.999f, 0.999f);
        if (!std::isfinite(L[i]) || !std::isfinite(R[i])) { L[i] = R[i] = 0; bad = true; }
    }
    if (bad) reset();
}
}
