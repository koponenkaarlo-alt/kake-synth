#pragma once
#include "Voice.h"
#include "Fx.h"
#include <array>
#include <vector>

namespace synth
{
class Engine
{
public:
    static constexpr int NUM_VOICES = 8;

    void prepare(double sampleRate, int maxBlock);
    void reset();
    void setParams(const float* realValues);    // NUM_PARAMS floats, real (denormalised) units
    void setTransport(double bpm) { global.bpm = bpm > 20.0 ? bpm : 120.0; }

    void noteOn(int note, float velocity01);
    void noteOff(int note);
    void allNotesOff();
    void pitchBend(float bend);                // -1..1
    void controller(int cc, float value01);
    void channelPressure(float v01) { global.aftertouch = v01; }

    // Call with small chunks (<= 64 samples) so parameter smoothing stays fine grained.
    void process(float* L, float* R, int n);
    int activeVoices() const;

private:
    void applyMacrosAndSmooth(int n);
    void startVoice(Voice& v, int note, float vel, bool retrigger);
    Voice* findFreeVoice();
    void releaseHeld(int note);

    double sr = 44100.0;
    float target[synthp::NUM_PARAMS] = {};
    float smoothed[synthp::NUM_PARAMS] = {};
    float eff[synthp::NUM_PARAMS] = {};
    bool firstParams = true;
    std::array<Voice, NUM_VOICES> voices;
    std::vector<int> noteStack;
    Global global;
    FxChain fx;
    uint64_t ageCounter = 0;
    float lastNote = 60.0f;
    bool pedal = false;
    bool monoPedalHold = false;
};
}
