#pragma once
namespace wt
{
constexpr int SIZE = 2048;
constexpr int NUM_LEVELS = 11; // level L holds (1024 >> L) harmonics
constexpr int NUM_TABLES = 12;

extern const float* g_tableBase;          // valid after init()
void init();                              // idempotent + thread safe
const float* table(int t, int level);     // SIZE + 1 floats (guard point)
const char* name(int t);
inline const float* tableFast(int t, int level) { return g_tableBase + ((long) t * NUM_LEVELS + level) * (SIZE + 1); } // call init() first
int levelForHarmonics(float maxHarmonics);
}
