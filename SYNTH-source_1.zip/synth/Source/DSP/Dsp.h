#pragma once
#include <cmath>
#include <cstdint>
#include <algorithm>
#include <vector>

namespace dsp
{
constexpr float PI = 3.14159265358979f;
constexpr float TWO_PI = 6.28318530717959f;

inline float fastTanh(float x)
{
    if (x < -3.0f) return -1.0f;
    if (x > 3.0f) return 1.0f;
    const float x2 = x * x;
    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}
// cheap sine for modulation (cycles in, ~0.1% error)
inline float fastSinCycles(float x)
{
    x -= std::floor(x);
    x = x < 0.5f ? x : x - 1.0f;                 // -0.5..0.5
    const float y = 8.0f * x * (1.0f - 2.0f * std::fabs(x));   // parabola approx
    return y * (0.775f + 0.225f * std::fabs(y));
}
inline float lerp(float a, float b, float t) { return a + (b - a) * t; }
inline float clampf(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
inline float midiToFreq(float note) { return 440.0f * std::exp2((note - 69.0f) * (1.0f / 12.0f)); }
inline bool finiteOr(float x) { return std::isfinite(x); }

struct Rng
{
    uint32_t s = 22222u;
    explicit Rng(uint32_t seed = 22222u) : s(seed ? seed : 1u) {}
    uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float uni() { return (float) (next() >> 8) * (1.0f / 16777216.0f); }
    float bi() { return uni() * 2.0f - 1.0f; }
};

struct OnePole
{
    float a = 0.0f, z = 0.0f;
    void setCutoff(float fc, float sr) { a = 1.0f - std::exp(-TWO_PI * clampf(fc, 1.0f, sr * 0.45f) / sr); }
    float lp(float x) { z += a * (x - z); return z; }
    void reset() { z = 0; }
};

struct Smooth
{
    float v = 0.0f, a = 0.001f; bool init = false;
    void setTime(float seconds, float sr) { a = 1.0f - std::exp(-1.0f / std::max(1.0e-4f, seconds * sr)); }
    float next(float target) { if (!init) { v = target; init = true; } v += a * (target - v); return v; }
};

struct DCBlock
{
    float x1 = 0, y1 = 0;
    float process(float x) { const float y = x - x1 + 0.995f * y1; x1 = x; y1 = y; return y; }
};

// Zavalishin TPT state variable filter
struct SVF
{
    float g = 0.1f, k = 1.0f, a1 = 0, a2 = 0, a3 = 0, ic1 = 0, ic2 = 0;
    void set(float fc, float q, float sr)
    {
        fc = clampf(fc, 10.0f, sr * 0.45f);
        g = std::tan(PI * fc / sr);
        k = 1.0f / std::max(0.3f, q);
        a1 = 1.0f / (1.0f + g * (g + k)); a2 = g * a1; a3 = g * a2;
    }
    inline void tick(float v0, float& lp, float& bp, float& hp)
    {
        const float v3 = v0 - ic2;
        const float v1 = a1 * ic1 + a2 * v3;
        const float v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0f * v1 - ic1; ic2 = 2.0f * v2 - ic2;
        bp = v1; lp = v2; hp = v0 - k * v1 - v2;
    }
    void reset() { ic1 = ic2 = 0; }
};

// Stereo multimode filter unit: LP12(svf) / Ladder24 / HP / BP / Notch
struct FilterUnit
{
    enum Type { LP12 = 0, LADDER = 1, HP = 2, BP = 3, NOTCH = 4 };
    SVF svf[2];
    float y[2][4] = {}, t[2][4] = {};
    Type type = LP12;
    float ladA = 0.1f, ladK = 0.0f, drive = 0.0f, sr = 44100.0f;

    void set(Type ty, float fc, float res, float drv, float sampleRate)
    {
        type = ty; sr = sampleRate; drive = drv;
        fc = clampf(fc, 20.0f, sampleRate * 0.45f);
        res = clampf(res, 0.0f, 1.0f);
        if (ty == LADDER)
        {
            ladA = 1.0f - std::exp(-TWO_PI * std::min(fc, sampleRate * 0.4f) / sampleRate);
            ladK = res * 3.95f;
        }
        else
        {
            const float q = 0.55f + res * res * 20.0f;
            svf[0].set(fc, q, sampleRate); svf[1] = svf[0];
        }
    }
    inline float sat(float x) const
    {
        if (drive <= 0.0001f) return x;
        const float wet = fastTanh(x * (1.0f + drive * 8.0f));
        return lerp(x, wet, std::min(1.0f, drive * 4.0f));
    }
    inline float tickCh(int c, float in)
    {
        float x = sat(in);
        if (type == LADDER)
        {
            float u = fastTanh(x - ladK * y[c][3]);
            for (int s = 0; s < 4; ++s)
            {
                y[c][s] += ladA * (u - t[c][s]);
                t[c][s] = fastTanh(y[c][s]);
                u = t[c][s];
            }
            return y[c][3] * (1.0f + ladK * 0.18f);
        }
        float lp, bp, hp;
        svf[c].tick(x, lp, bp, hp);
        switch (type)
        {
            case HP: return hp;
            case BP: return bp * (svf[c].k);
            case NOTCH: return lp + hp;
            default: return lp;
        }
    }
    inline void process(float& l, float& r) { l = tickCh(0, l); r = tickCh(1, r); }
    void reset() { svf[0].reset(); svf[1].reset(); for (int c = 0; c < 2; ++c) for (int s = 0; s < 4; ++s) y[c][s] = t[c][s] = 0; }
};

struct Adsr
{
    enum Stage { Idle, Attack, Decay, Sustain, Release };
    Stage st = Idle; float v = 0, aRate = 0.01f, dCoef = 0.999f, s = 0.7f, rCoef = 0.999f;
    void set(float a, float d, float sus, float r, float sr)
    {
        aRate = 1.0f / (std::max(a, 0.0005f) * sr);
        dCoef = std::exp(-4.6f / (std::max(d, 0.001f) * sr));
        rCoef = std::exp(-4.6f / (std::max(r, 0.002f) * sr));
        s = sus;
    }
    void gateOn() { st = Attack; }
    void gateOff() { if (st != Idle) st = Release; }
    inline float tick()
    {
        switch (st)
        {
            case Attack: v += aRate; if (v >= 1.0f) { v = 1.0f; st = Decay; } break;
            case Decay:  v = s + (v - s) * dCoef; if (std::fabs(v - s) < 1.0e-4f) { v = s; st = Sustain; } if (s < 1.0e-5f && v < 1.0e-5f) { v = 0; st = Idle; } break;
            case Sustain: v = s; if (s < 1.0e-5f) { v = 0; st = Idle; } break;
            case Release: v *= rCoef; if (v < 1.0e-4f) { v = 0; st = Idle; } break;
            default: v = 0; break;
        }
        return v;
    }
    void reset() { st = Idle; v = 0; }
};

struct Lfo
{
    float phase = 0, prev = 0, next = 0, sh = 0; Rng rng{777u};
    void reset(uint32_t seed) { rng = Rng(seed); phase = rng.uni() * 0.0f; prev = next = sh = rng.bi(); }
    // advance by 'inc' cycles, return -1..1
    float tick(float inc, int shape)
    {
        phase += inc;
        if (phase >= 1.0f) { phase -= std::floor(phase); prev = next; next = rng.bi(); sh = next; }
        switch (shape)
        {
            case 0: return std::sin(TWO_PI * phase);
            case 1: return 4.0f * std::fabs(phase - 0.5f) - 1.0f;
            case 2: return 2.0f * phase - 1.0f;
            case 3: return phase < 0.5f ? 1.0f : -1.0f;
            case 4: return sh;
            default: { const float x = phase * phase * (3.0f - 2.0f * phase); return prev + (next - prev) * x; }
        }
    }
};

// Circular buffer delay with linear interpolated read
struct DelayLine
{
    std::vector<float> buf; int size = 0, w = 0;
    void init(int n) { size = std::max(4, n); buf.assign((size_t) size, 0.0f); w = 0; }
    void clear() { std::fill(buf.begin(), buf.end(), 0.0f); }
    inline void write(float x) { buf[(size_t) w] = x; if (++w >= size) w = 0; }
    inline float read(float d) const
    {
        d = clampf(d, 1.0f, (float) (size - 2));
        float rp = (float) w - d; if (rp < 0) rp += (float) size;
        const int i0 = (int) rp; const float f = rp - (float) i0;
        const int i1 = (i0 + 1 >= size) ? 0 : i0 + 1;
        return buf[(size_t) i0] + (buf[(size_t) i1] - buf[(size_t) i0]) * f;
    }
};
} // namespace dsp
