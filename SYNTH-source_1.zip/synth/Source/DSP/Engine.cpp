#include "Engine.h"
#include <cmath>
#include <cstring>

using namespace synthp;
using namespace dsp;

namespace synth
{
void Engine::prepare(double sampleRate, int)
{
    sr = sampleRate;
    for (int i = 0; i < NUM_VOICES; ++i) voices[(size_t) i].prepare(sampleRate, (uint32_t) (i + 1) * 31u);
    fx.prepare(sampleRate);
    for (int i = 0; i < NUM_PARAMS; ++i) target[i] = smoothed[i] = eff[i] = kParams[i].defV;
    firstParams = true;
    noteStack.reserve(32);
    reset();
}

void Engine::reset()
{
    for (auto& v : voices) v.kill();
    noteStack.clear(); pedal = false; monoPedalHold = false;
    global.bend = 0; global.modWheel = 0; global.aftertouch = 0;
    fx.reset();
}

void Engine::setParams(const float* p)
{
    for (int i = 0; i < NUM_PARAMS; ++i)
        target[i] = std::isfinite(p[i]) ? clampToParam(i, p[i]) : kParams[i].defV;
    if (firstParams) { std::memcpy(smoothed, target, sizeof(target)); firstParams = false; }
}

int Engine::activeVoices() const
{
    int n = 0; for (auto& v : voices) if (v.isActive()) ++n; return n;
}

Voice* Engine::findFreeVoice()
{
    Voice* best = nullptr;
    for (auto& v : voices) if (!v.isActive()) return &v;
    // steal: quietest releasing voice, otherwise oldest
    for (auto& v : voices) if (v.isReleasing() && (!best || v.level() < best->level())) best = &v;
    if (best) return best;
    for (auto& v : voices) if (!best || v.age < best->age) best = &v;
    return best;
}

void Engine::startVoice(Voice& v, int note, float vel, bool retrigger)
{
    const float glide = smoothed[GLIDE];
    const float start = (glide > 0.0005f) ? lastNote : (float) note;
    v.noteOn(note, vel, start, retrigger, ++ageCounter);
    lastNote = (float) note;
}

void Engine::noteOn(int note, float vel)
{
    const int mode = (int) (smoothed[VOICE_MODE] + 0.5f);
    vel = clampf(vel, 0.0f, 1.0f);
    if (mode == 0)
    {
        // retrigger same note on same voice if already playing
        for (auto& v : voices) if (v.isActive() && v.gateOn() && v.note == note && !v.sustained) { startVoice(v, note, vel, true); return; }
        if (Voice* v = findFreeVoice()) startVoice(*v, note, vel, true);
        return;
    }
    // mono / legato
    noteStack.erase(std::remove(noteStack.begin(), noteStack.end(), note), noteStack.end());
    if (noteStack.size() >= 30) noteStack.erase(noteStack.begin());
    noteStack.push_back(note);
    Voice& v = voices[0];
    for (size_t i = 1; i < voices.size(); ++i) voices[i].noteOff();
    const bool legatoNow = (mode == 2) && v.isActive() && v.gateOn();
    if (legatoNow) { v.retarget(note); v.age = ++ageCounter; lastNote = (float) note; }
    else
    {
        const float glide = smoothed[GLIDE];
        const float start = (glide > 0.0005f) ? lastNote : (float) note;
        v.noteOn(note, vel, start, true, ++ageCounter); lastNote = (float) note;
    }
}

void Engine::noteOff(int note)
{
    const int mode = (int) (smoothed[VOICE_MODE] + 0.5f);
    if (mode == 0)
    {
        for (auto& v : voices)
            if (v.isActive() && v.gateOn() && v.note == note && !v.sustained)
            {
                if (pedal) v.sustained = true; else v.noteOff();
            }
        return;
    }
    noteStack.erase(std::remove(noteStack.begin(), noteStack.end(), note), noteStack.end());
    Voice& v = voices[0];
    if (!noteStack.empty())
    {
        const int back = noteStack.back();
        if (v.note != back) { v.retarget(back); lastNote = (float) back; if (mode == 1) v.noteOn(back, 0.8f, lastNote, true, ++ageCounter); }
    }
    else if (pedal) monoPedalHold = true;
    else v.noteOff();
}

void Engine::allNotesOff()
{
    noteStack.clear(); monoPedalHold = false;
    for (auto& v : voices) if (v.isActive()) v.noteOff();
}

void Engine::pitchBend(float b) { global.bend = clampf(b, -1.0f, 1.0f); }

void Engine::controller(int cc, float v)
{
    switch (cc)
    {
        case 1: global.modWheel = v; break;
        case 64:
        {
            const bool down = v >= 0.5f;
            if (pedal && !down)
            {
                for (auto& vo : voices) if (vo.sustained) vo.noteOff();
                if (monoPedalHold) { voices[0].noteOff(); monoPedalHold = false; }
            }
            pedal = down; break;
        }
        case 120: for (auto& vo : voices) vo.kill(); noteStack.clear(); break;
        case 123: allNotesOff(); break;
        default: break;
    }
}

void Engine::applyMacrosAndSmooth(int n)
{
    const float a = 1.0f - std::exp(-(float) n / (float) (sr * 0.008));
    for (int i = 0; i < NUM_PARAMS; ++i)
    {
        if (kParams[i].type == PType::Float && kParams[i].step == 0.0f) smoothed[i] += a * (target[i] - smoothed[i]);
        else smoothed[i] = target[i];
    }
    std::memcpy(eff, smoothed, sizeof(eff));
    const float haze = smoothed[MAC_HAZE], grit = smoothed[MAC_GRIT], drift = smoothed[MAC_DRIFT], dark = smoothed[MAC_DARK];
    auto add = [&](int i, float d) { eff[i] = clampToParam(i, eff[i] + d); };
    auto mul = [&](int i, float f) { eff[i] = clampToParam(i, eff[i] * f); };
    if (haze > 0.0f)
    {
        add(REV_MIX, 0.35f * haze); add(REV_DECAY, 0.2f * haze); add(REV_SIZE, 0.1f * haze);
        add(CHO_MIX, 0.45f * haze); add(TAPE_AMT, 0.45f * haze); add(DLY_MIX, 0.12f * haze);
        mul(TAPE_TONE, 1.0f - 0.55f * haze);
    }
    if (grit > 0.0f)
    {
        add(DIST_MIX, 0.7f * grit); add(DIST_DRIVE, 0.6f * grit);
        add(CRUSH_MIX, 0.45f * grit); add(CRUSH_BITS, -5.0f * grit); add(CRUSH_RATE, 6.0f * grit);
        add(F1_DRIVE, 0.3f * grit);
    }
    if (drift > 0.0f) { add(DRIFT, drift); add(TAPE_AMT, 0.3f * drift); add(CHO_MIX, 0.15f * drift); }
    if (dark > 0.0f)
    {
        mul(F1_CUT, std::exp2(-3.5f * dark)); mul(F2_CUT, std::exp2(-2.0f * dark));
        add(REV_DAMP, 0.4f * dark); mul(DLY_TONE, 1.0f - 0.6f * dark);
        mul(UW_CUT, std::pow(0.06f, dark)); add(REV_MIX, 0.1f * dark);
    }
}

void Engine::process(float* L, float* R, int n)
{
    if (n <= 0) return;
    applyMacrosAndSmooth(n);
    std::memset(L, 0, sizeof(float) * (size_t) n);
    std::memset(R, 0, sizeof(float) * (size_t) n);
    for (auto& v : voices) v.render(L, R, n, eff, global);
    fx.process(L, R, n, eff, global.bpm);
}
}
