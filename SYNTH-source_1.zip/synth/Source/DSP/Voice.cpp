#include "Voice.h"
#include "Wavetables.h"
#include <cmath>

using namespace dsp;
using namespace synthp;

namespace synth
{
static const float kDivBeats[9] = { 4.0f, 2.0f, 1.0f, 0.5f, 0.25f, 1.0f / 3.0f, 1.0f / 6.0f, 1.5f, 0.75f };

void Voice::prepare(double sampleRate, uint32_t seed)
{
    sr = (float) sampleRate; dt = 1.0f / sr;
    rng = Rng(seed * 2654435761u + 17u);
    lfo[0].reset(seed + 1); lfo[1].reset(seed + 101);
    amp.reset(); env2.reset(); f1.reset(); f2.reset();
    wt::init();
}

void Voice::kill() { amp.reset(); env2.reset(); f1.reset(); f2.reset(); sustained = false; note = -1; }

void Voice::noteOn(int n, float vel, float startNote, bool retrigger, uint64_t a)
{
    note = n; age = a; velocity = vel; sustained = false;
    targetNote = (float) n; curNote = startNote;
    noteRand = rng.bi();
    if (retrigger || !isActive())
    {
        for (int o = 0; o < 2; ++o) for (int u = 0; u < MAX_UNI; ++u) phase[o][u] = rng.uni();
        subPhase = 0;
        lfo[0].reset(rng.next()); lfo[1].reset(rng.next());
        lfo[0].phase = 0; lfo[1].phase = 0;
        if (!isActive()) { f1.reset(); f2.reset(); amp.v = 0; env2.v = 0; ampGain = 0; }
        amp.gateOn(); env2.gateOn();
    }
}

void Voice::retarget(int n) { note = n; targetNote = (float) n; }

void Voice::noteOff() { amp.gateOff(); env2.gateOff(); sustained = false; }

float Voice::readTable(int t0, int t1, float frac, int level, float ph)
{
    const float pos = ph * (float) wt::SIZE;
    const int i0 = (int) pos; const float f = pos - (float) i0;
    const float* a = wt::tableFast(t0, level);
    float s = a[i0] + (a[i0 + 1] - a[i0]) * f;
    if (frac > 0.0001f)
    {
        const float* b = wt::tableFast(t1, level);
        const float s2 = b[i0] + (b[i0 + 1] - b[i0]) * f;
        s += (s2 - s) * frac;
    }
    return s;
}

void Voice::control(int blk, const float* p, const Global& g)
{
    // glide
    const float glideT = p[GLIDE];
    if (glideT > 0.0005f) curNote += (targetNote - curNote) * (1.0f - std::exp(-(float) blk * dt / (glideT * 0.33f)));
    else curNote = targetNote;

    // drift (slow random walk, per voice)
    driftCount -= blk;
    if (driftCount <= 0) { driftPT = rng.bi(); driftCT = rng.bi(); driftCount = (int) (sr * 0.25f); }
    const float dl = 1.0f - std::exp(-(float) blk * dt / 0.6f);
    driftP += (driftPT - driftP) * dl; driftC += (driftCT - driftC) * dl;
    const float driftAmt = p[DRIFT];

    // LFOs
    float lfoV[2];
    for (int i = 0; i < 2; ++i)
    {
        const int base = (i == 0) ? L1_SHAPE : L2_SHAPE;
        float rate = p[base + 1];
        if (p[base + 2] > 0.5f)
        {
            const float beats = kDivBeats[std::clamp((int) (p[base + 3] + 0.5f), 0, 8)];
            rate = (float) (g.bpm / 60.0) / beats;
        }
        lfoV[i] = lfo[i].tick(rate * (float) blk * dt, (int) (p[base] + 0.5f));
    }

    // sources
    float src[NUM_SRC] = {};
    src[SRC_LFO1] = lfoV[0]; src[SRC_LFO2] = lfoV[1]; src[SRC_ENV2] = env2.v; src[SRC_VEL] = velocity;
    src[SRC_MODWHEEL] = g.modWheel; src[SRC_AFTERTOUCH] = g.aftertouch;
    src[SRC_KEY] = clampf((curNote - 60.0f) / 36.0f, -1.0f, 1.0f); src[SRC_RANDOM] = noteRand;
    float mod[NUM_DST] = {};
    for (int m = 0; m < NUM_MOD_SLOTS; ++m)
    {
        const int base = M1_SRC + m * 3;
        const int s = (int) (p[base] + 0.5f), d = (int) (p[base + 1] + 0.5f);
        if (s > 0 && d > 0) mod[d] += src[s] * p[base + 2];
    }

    // pitch
    const float bendSemis = g.bend * p[BEND_RANGE];
    const float notePitch = curNote + bendSemis + mod[DST_PITCH] * 24.0f + driftP * driftAmt * 0.35f;
    const float srcNyq = 0.5f * sr;

    for (int o = 0; o < 2; ++o)
    {
        const int b = O1_TABLE + o * (O2_TABLE - O1_TABLE);
        const float pitch = notePitch + p[b + 1] * 12.0f + p[b + 2] + p[b + 3] * 0.01f;
        const float f = midiToFreq(pitch);
        int n = std::clamp((int) (p[b + 5] + 0.5f), 1, MAX_UNI);
        uni[o] = n;
        float det = p[b + 6] + mod[DST_DETUNE] * 0.5f; det = clampf(det, 0.0f, 1.0f);
        const float maxCents = det * 50.0f;
        const float spread = p[b + 7];
        float fmaxRatio = 1.0f;
        for (int u = 0; u < n; ++u)
        {
            const float pos = (n > 1) ? ((float) u / (float) (n - 1)) * 2.0f - 1.0f : 0.0f;
            const float ratio = std::exp2(pos * maxCents / 1200.0f);
            fmaxRatio = std::max(fmaxRatio, ratio);
            inc[o][u] = f * ratio * dt;
            const float pan = pos * spread;
            const float ang = (pan + 1.0f) * 0.25f * PI;
            gL[o][u] = std::cos(ang); gR[o][u] = std::sin(ang);
        }
        uniNorm[o] = 1.0f / std::sqrt((float) n);
        lvl[o] = wt::levelForHarmonics(srcNyq / std::max(20.0f, f * fmaxRatio));
        float tp = p[b] + mod[o == 0 ? DST_TABLE1 : DST_TABLE2] * 0.5f;
        tpos[o] = clampf(tp, 0.0f, 1.0f) * (float) (wt::NUM_TABLES - 1);
        if (o == 0) level1 = p[b + 4]; else level2 = p[b + 4];
        if (o == 0) subInc = midiToFreq(pitch - 12.0f * (1.0f + p[SUB_OCT])) * dt;
    }
    subLevel = p[SUB_LEVEL]; subWave = (int) (p[SUB_WAVE] + 0.5f);
    noiseLevel = p[NOISE_LEVEL] * 0.5f;
    noiseLp.setCutoff(200.0f * std::exp2(p[NOISE_TONE] * 6.5f), sr);
    fmAmt = clampf(p[FM_AMT] + mod[DST_FM] * 0.5f, 0.0f, 1.0f); ringAmt = p[RING_AMT];

    // filters
    f1Type = (int) (p[F1_TYPE] + 0.5f);
    const float envOct = p[F1_ENV] * 6.0f * env2.v;
    const float shift = p[F1_KEY] * (curNote - 60.0f) / 12.0f + envOct + mod[DST_CUTOFF] * 5.0f + driftC * driftAmt * 0.15f;
    const float c1 = p[F1_CUT] * std::exp2(shift);
    f1.set((FilterUnit::Type) f1Type, c1, clampf(p[F1_RES] + mod[DST_RES] * 0.5f, 0.0f, 1.0f),
           clampf(p[F1_DRIVE] + mod[DST_DRIVE] * 0.5f, 0.0f, 1.0f), sr);
    f2Mode = (int) (p[F2_MODE] + 0.5f);
    if (f2Mode > 0)
    {
        const float c2 = p[F2_CUT] * std::exp2(shift - envOct);
        static const FilterUnit::Type map2[4] = { FilterUnit::LP12, FilterUnit::HP, FilterUnit::BP, FilterUnit::NOTCH };
        f2.set(map2[std::clamp((int) (p[F2_TYPE] + 0.5f), 0, 3)], c2, p[F2_RES], 0.0f, sr);
    }

    // amp
    const float velGain = 0.35f + 0.65f * velocity;
    ampGainT = velGain * std::max(0.0f, 1.0f + mod[DST_AMP]);
    const float pan = clampf(mod[DST_PAN], -1.0f, 1.0f);
    const float ang = (pan + 1.0f) * 0.25f * PI;
    panLT = std::cos(ang) * 1.41421356f; panRT = std::sin(ang) * 1.41421356f;

    amp.set(p[AMP_A], p[AMP_D], p[AMP_S], p[AMP_R], sr);
    env2.set(p[ENV2_A], p[ENV2_D], p[ENV2_S], p[ENV2_R], sr);
}

void Voice::render(float* L, float* R, int n, const float* p, const Global& g)
{
    if (!isActive()) return;
    int i = 0;
    while (i < n && isActive())
    {
        const int blk = std::min(CTRL, n - i);
        control(blk, p, g);
        const float gStep = (ampGainT - ampGain) / (float) blk;
        const float lStep = (panLT - panL) / (float) blk, rStep = (panRT - panR) / (float) blk;

        for (int j = 0; j < blk; ++j, ++i)
        {
            // osc 2 first (FM / ring source)
            float l2 = 0, r2 = 0;
            if (level2 > 0.0001f || fmAmt > 0.0001f || ringAmt > 0.0001f)
            {
                const int t0 = (int) tpos[1]; const int t1 = std::min(t0 + 1, wt::NUM_TABLES - 1); const float fr = tpos[1] - (float) t0;
                for (int u = 0; u < uni[1]; ++u)
                {
                    float& ph = phase[1][u]; ph += inc[1][u]; if (ph >= 1.0f) ph -= 1.0f;
                    const float s = readTable(t0, t1, fr, lvl[1], ph);
                    l2 += s * gL[1][u]; r2 += s * gR[1][u];
                }
                l2 *= uniNorm[1]; r2 *= uniNorm[1];
            }
            const float mono2 = 0.5f * (l2 + r2);

            float l1 = 0, r1 = 0;
            {
                const int t0 = (int) tpos[0]; const int t1 = std::min(t0 + 1, wt::NUM_TABLES - 1); const float fr = tpos[0] - (float) t0;
                const float pm = fmAmt * 2.5f * mono2;
                for (int u = 0; u < uni[0]; ++u)
                {
                    float& ph = phase[0][u]; ph += inc[0][u]; if (ph >= 1.0f) ph -= 1.0f;
                    float pp = ph + pm; pp -= std::floor(pp);
                    const float s = readTable(t0, t1, fr, lvl[0], pp);
                    l1 += s * gL[0][u]; r1 += s * gR[0][u];
                }
                l1 *= uniNorm[0]; r1 *= uniNorm[0];
            }
            if (ringAmt > 0.0001f)
            {
                l1 = lerp(l1, l1 * l2 * 3.0f, ringAmt); r1 = lerp(r1, r1 * r2 * 3.0f, ringAmt);
            }
            float outL = l1 * level1 + l2 * level2;
            float outR = r1 * level1 + r2 * level2;

            if (subLevel > 0.0001f)
            {
                subPhase += subInc; if (subPhase >= 1.0f) subPhase -= 1.0f;
                const float s = (subWave == 0) ? std::sin(TWO_PI * subPhase) : (4.0f * std::fabs(subPhase - 0.5f) - 1.0f);
                outL += s * subLevel * 0.8f; outR += s * subLevel * 0.8f;
            }
            if (noiseLevel > 0.0001f)
            {
                const float nz = noiseLp.lp(rng.bi()) * noiseLevel * (1.0f + 3.0f * (1.0f - std::min(1.0f, noiseLp.a * 8.0f)));
                outL += nz; outR += nz * 0.9f + rng.bi() * noiseLevel * 0.02f;
            }

            // filters
            if (f2Mode == 1) { f1.process(outL, outR); f2.process(outL, outR); }
            else if (f2Mode == 2)
            {
                float aL = outL, aR = outR, bL = outL, bR = outR;
                f1.process(aL, aR); f2.process(bL, bR);
                outL = 0.5f * (aL + bL); outR = 0.5f * (aR + bR);
            }
            else f1.process(outL, outR);

            env2.tick();
            const float e = amp.tick();
            ampGain += gStep; panL += lStep; panR += rStep;
            const float gain = e * ampGain * 0.7f;
            L[i] += outL * gain * panL;
            R[i] += outR * gain * panR;
        }
        ampGain = ampGainT; panL = panLT; panR = panRT;
    }
}
}
