#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <atomic>
#include <array>
#include "Params.h"
#include "DSP/Engine.h"

class SynthAudioProcessor : public juce::AudioProcessor
{
public:
    SynthAudioProcessor();
    ~SynthAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "SYNTH"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 8.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    // ---- presets (message thread only)
    void loadFactoryPreset(int index);
    bool saveUserPreset(const juce::String& name);
    bool loadUserPreset(const juce::File& file);
    static juce::File getUserPresetDir();
    juce::String getCurrentPresetName() const { return currentPresetName; }

    // ---- visualisation taps (audio thread writes, GUI reads; races are benign for drawing)
    static constexpr int kScopeSize = 4096;
    void copyScope(float* dest, int n) const;

    juce::AudioProcessorValueTreeState apvts;
    std::atomic<int> voiceCount { 0 };

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void handleMidi(const juce::MidiMessage& m);

    synth::Engine engine;
    std::array<std::atomic<float>*, synthp::NUM_PARAMS> paramPtrs {};
    float paramValues[synthp::NUM_PARAMS] {};
    std::array<float, kScopeSize> scope {};
    std::atomic<int> scopeWrite { 0 };
    juce::String currentPresetName { "Init" };
    juce::AudioBuffer<float> monoScratch;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SynthAudioProcessor)
};
