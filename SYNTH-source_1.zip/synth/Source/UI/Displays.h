#pragma once
#include <juce_dsp/juce_dsp.h>
#include "Look.h"
#include "../PluginProcessor.h"
#include "../DSP/Wavetables.h"

namespace ui
{
class ScopeView : public juce::Component, private juce::Timer
{
public:
    explicit ScopeView(SynthAudioProcessor& p) : proc(p) { startTimerHz(30); }
    void timerCallback() override { proc.copyScope(buf.data(), N); repaint(); }
    void paint(juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();
        g.setColour(juce::Colour(0xff06060c)); g.fillRoundedRectangle(r, 3.0f);
        g.setColour(col::panelEdge); g.drawRoundedRectangle(r.reduced(0.5f), 3.0f, 1.0f);
        g.setColour(col::panelEdge.withAlpha(0.6f)); g.drawHorizontalLine((int) r.getCentreY(), r.getX() + 2, r.getRight() - 2);
        // trigger on a rising zero crossing so the picture holds still
        int start = 0;
        for (int i = 8; i < N / 2; ++i) if (buf[(size_t) i - 1] < 0.0f && buf[(size_t) i] >= 0.0f) { start = i; break; }
        const int show = 1024;
        juce::Path p;
        for (int x = 0; x < (int) r.getWidth(); ++x)
        {
            const float t = (float) x / r.getWidth();
            const float v = juce::jlimit(-1.0f, 1.0f, buf[(size_t) std::min(N - 1, start + (int) (t * (float) show))] * 1.6f);
            const float y = r.getCentreY() - v * (r.getHeight() * 0.44f);
            if (x == 0) p.startNewSubPath(r.getX(), y); else p.lineTo(r.getX() + (float) x, y);
        }
        for (int i = 3; i >= 1; --i) { g.setColour(col::ice.withAlpha(0.06f * (float) (4 - i))); g.strokePath(p, juce::PathStrokeType(1.0f + (float) i * 1.8f)); }
        g.setColour(col::ice); g.strokePath(p, juce::PathStrokeType(1.3f));
        g.setColour(col::textDim); g.setFont(hudFont(8.5f)); g.drawText("SCOPE", getLocalBounds().reduced(5, 2), juce::Justification::topLeft);
    }
private:
    static constexpr int N = 2048;
    SynthAudioProcessor& proc; std::array<float, N> buf {};
};

class SpectrumView : public juce::Component, private juce::Timer
{
public:
    explicit SpectrumView(SynthAudioProcessor& p) : proc(p), fft(11), window((size_t) N, juce::dsp::WindowingFunction<float>::hann)
    { startTimerHz(30); mag.fill(0.0f); }
    void timerCallback() override
    {
        proc.copyScope(work.data(), N);
        std::fill(work.begin() + N, work.end(), 0.0f);
        window.multiplyWithWindowingTable(work.data(), (size_t) N);
        fft.performFrequencyOnlyForwardTransform(work.data());
        const double sr = proc.getSampleRate() > 0 ? proc.getSampleRate() : 44100.0;
        for (int i = 0; i < BINS; ++i)
        {
            const float f = 25.0f * std::pow(20000.0f / 25.0f, (float) i / (float) (BINS - 1));
            const float bin = f / (float) sr * (float) N;
            const int b0 = std::min(N / 2 - 1, (int) bin);
            const float m = work[(size_t) b0] / (float) N * 2.0f;
            const float db = juce::Decibels::gainToDecibels(m, -100.0f);
            const float v = juce::jlimit(0.0f, 1.0f, (db + 90.0f) / 80.0f);
            mag[(size_t) i] = v > mag[(size_t) i] ? v : mag[(size_t) i] * 0.88f + v * 0.12f;
        }
        repaint();
    }
    void paint(juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();
        g.setColour(juce::Colour(0xff06060c)); g.fillRoundedRectangle(r, 3.0f);
        g.setColour(col::panelEdge); g.drawRoundedRectangle(r.reduced(0.5f), 3.0f, 1.0f);
        juce::Path line, fill;
        fill.startNewSubPath(r.getX(), r.getBottom());
        for (int i = 0; i < BINS; ++i)
        {
            const float x = r.getX() + r.getWidth() * (float) i / (float) (BINS - 1);
            const float y = r.getBottom() - mag[(size_t) i] * (r.getHeight() - 4.0f) - 1.0f;
            if (i == 0) line.startNewSubPath(x, y); else line.lineTo(x, y);
            fill.lineTo(x, y);
        }
        fill.lineTo(r.getRight(), r.getBottom()); fill.closeSubPath();
        g.setGradientFill(juce::ColourGradient(col::violet.withAlpha(0.55f), 0, r.getY(), col::violet.withAlpha(0.02f), 0, r.getBottom(), false));
        g.fillPath(fill);
        g.setColour(col::violet.withAlpha(0.25f)); g.strokePath(line, juce::PathStrokeType(3.5f));
        g.setColour(juce::Colour(0xffc9a4ff)); g.strokePath(line, juce::PathStrokeType(1.2f));
        g.setColour(col::textDim); g.setFont(hudFont(8.5f)); g.drawText("SPECTRUM", getLocalBounds().reduced(5, 2), juce::Justification::topLeft);
    }
private:
    static constexpr int N = 2048, BINS = 160;
    SynthAudioProcessor& proc; juce::dsp::FFT fft; juce::dsp::WindowingFunction<float> window;
    std::array<float, N * 2> work {}; std::array<float, BINS> mag;
};

// Pseudo-3D stack of all wavetables with the two oscillators' current morph positions highlighted
class WavetableView : public juce::Component, private juce::Timer
{
public:
    explicit WavetableView(SynthAudioProcessor& p) : proc(p)
    {
        pos1 = proc.apvts.getRawParameterValue("o1_table"); pos2 = proc.apvts.getRawParameterValue("o2_table");
        startTimerHz(20);
    }
    void timerCallback() override
    {
        const float a = pos1->load(), b = pos2->load();
        if (a != last1 || b != last2) { last1 = a; last2 = b; repaint(); }
    }
    void paint(juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();
        g.setColour(juce::Colour(0xff06060c)); g.fillRoundedRectangle(r, 3.0f);
        g.setColour(col::panelEdge); g.drawRoundedRectangle(r.reduced(0.5f), 3.0f, 1.0f);
        const int T = wt::NUM_TABLES, P = 96;
        const float w = r.getWidth() - 34.0f, h = r.getHeight() - 24.0f;
        const float sliceH = h * 0.42f, dx = 22.0f / (float) T, dy = (h - sliceH) / (float) (T - 1);
        auto drawSlice = [&](float tpos, float ox, float oy, juce::Colour c, float alpha, float thick)
        {
            const int t0 = juce::jlimit(0, T - 1, (int) tpos), t1 = std::min(T - 1, t0 + 1); const float fr = tpos - (float) t0;
            const float* a = wt::table(t0, 4); const float* b = wt::table(t1, 4);
            juce::Path p;
            for (int i = 0; i < P; ++i)
            {
                const int idx = i * (wt::SIZE / P);
                const float v = a[idx] + (b[idx] - a[idx]) * fr;
                const float x = r.getX() + 6.0f + ox + w * (float) i / (float) (P - 1);
                const float y = r.getY() + 8.0f + oy + sliceH * 0.5f - v * sliceH * 0.55f;
                if (i == 0) p.startNewSubPath(x, y); else p.lineTo(x, y);
            }
            g.setColour(c.withAlpha(alpha)); g.strokePath(p, juce::PathStrokeType(thick));
        };
        for (int t = T - 1; t >= 0; --t)   // back to front
            drawSlice((float) t, dx * (float) (T - 1 - t), dy * (float) t, col::textDim, 0.55f, 0.9f);
        auto hi = [&](float pos, juce::Colour c)
        {
            const float tp = juce::jlimit(0.0f, 1.0f, pos) * (float) (T - 1);
            drawSlice(tp, dx * ((float) (T - 1) - tp), dy * tp, c, 0.25f, 4.0f);
            drawSlice(tp, dx * ((float) (T - 1) - tp), dy * tp, c, 1.0f, 1.6f);
        };
        hi(pos2->load(), col::red); hi(pos1->load(), col::ice);
        g.setColour(col::textDim); g.setFont(hudFont(8.5f));
        g.drawText("WAVETABLE", getLocalBounds().reduced(5, 2), juce::Justification::topLeft);
        g.setColour(col::ice); g.setFont(hudFont(9.0f, true));
        g.drawText(juce::String(wt::name(juce::roundToInt(pos1->load() * (float) (T - 1)))), getLocalBounds().reduced(5, 2), juce::Justification::bottomLeft);
        g.setColour(col::red);
        g.drawText(juce::String(wt::name(juce::roundToInt(pos2->load() * (float) (T - 1)))), getLocalBounds().reduced(5, 2), juce::Justification::bottomRight);
    }
private:
    SynthAudioProcessor& proc; std::atomic<float>* pos1; std::atomic<float>* pos2; float last1 = -1, last2 = -1;
};
}
