#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "Look.h"
#include "../Params.h"

namespace ui
{
using APVTS = juce::AudioProcessorValueTreeState;

class KnobControl : public juce::Component
{
public:
    KnobControl(APVTS& apvts, int paramIndex, const juce::String& label, juce::Colour accent, bool big = false)
        : text(label), isBig(big), att(apvts, synthp::kParams[paramIndex].id, slider)
    {
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        slider.setRotaryParameters(juce::MathConstants<float>::pi * 1.2f, juce::MathConstants<float>::pi * 2.8f, true);
        slider.setColour(juce::Slider::rotarySliderFillColourId, accent);
        slider.setMouseDragSensitivity(220);
        slider.setDoubleClickReturnValue(true, synthp::kParams[paramIndex].defV);
        slider.setScrollWheelEnabled(true);
        slider.addMouseListener(this, false);
        slider.onValueChange = [this] { repaint(); };
        slider.setTooltip(synthp::kParams[paramIndex].name);
        addAndMakeVisible(slider);
    }
    void resized() override
    {
        auto r = getLocalBounds();
        r.removeFromBottom(isBig ? 16 : 12);
        slider.setBounds(r);
    }
    void paint(juce::Graphics& g) override
    {
        auto r = getLocalBounds().removeFromBottom(isBig ? 16 : 12);
        const bool showVal = hover || slider.isMouseButtonDown();
        g.setColour(showVal ? col::ice : col::textDim);
        g.setFont(hudFont(isBig ? 12.0f : 9.5f, isBig));
        g.drawFittedText(showVal ? slider.getTextFromValue(slider.getValue()) : text, r, juce::Justification::centred, 1, 0.8f);
    }
    void mouseEnter(const juce::MouseEvent&) override { hover = true; repaint(); }
    void mouseExit(const juce::MouseEvent&) override { hover = false; repaint(); }
    juce::Slider slider;
private:
    juce::String text; bool isBig, hover = false;
    APVTS::SliderAttachment att;
};

class ChoiceControl : public juce::Component
{
public:
    ChoiceControl(APVTS& apvts, int paramIndex, const juce::String& label)
        : text(label), att(apvts, synthp::kParams[paramIndex].id, box)
    {
        juce::StringArray items; items.addTokens(synthp::kParams[paramIndex].choices, "|", "");
        if (box.getNumItems() == 0) box.addItemList(items, 1);
        box.setJustificationType(juce::Justification::centredLeft);
        addAndMakeVisible(box);
        // attachment created after items were added -> re-sync selection
        box.setSelectedItemIndex((int) synthp::kParams[paramIndex].defV, juce::dontSendNotification);
        if (auto* p = apvts.getParameter(synthp::kParams[paramIndex].id))
            box.setSelectedItemIndex(juce::roundToInt(p->convertFrom0to1(p->getValue())), juce::dontSendNotification);
    }
    void resized() override
    {
        auto r = getLocalBounds().reduced(2, 0);
        r.removeFromTop(13);
        box.setBounds(r.withSizeKeepingCentre(r.getWidth(), 22).withY(r.getY() + std::max(0, (r.getHeight() - 22) / 2 - 6)));
    }
    void paint(juce::Graphics& g) override
    {
        g.setColour(col::textDim); g.setFont(hudFont(9.5f));
        g.drawText(text, getLocalBounds().removeFromTop(12), juce::Justification::centred);
    }
    juce::ComboBox box;
private:
    juce::String text;
    APVTS::ComboBoxAttachment att;
};

class ToggleControl : public juce::Component
{
public:
    ToggleControl(APVTS& apvts, int paramIndex, const juce::String& label, juce::Colour accent)
        : text(label), att(apvts, synthp::kParams[paramIndex].id, button)
    {
        button.setColour(juce::ToggleButton::tickColourId, accent);
        addAndMakeVisible(button);
    }
    void resized() override
    {
        auto r = getLocalBounds(); r.removeFromTop(13);
        button.setBounds(r.withSizeKeepingCentre(24, 24).translated(0, -6));
    }
    void paint(juce::Graphics& g) override
    {
        g.setColour(col::textDim); g.setFont(hudFont(9.5f));
        g.drawText(text, getLocalBounds().removeFromTop(12), juce::Justification::centred);
    }
    juce::ToggleButton button;
private:
    juce::String text;
    APVTS::ButtonAttachment att;
};

// One row of the mod matrix: source combo, destination combo, amount slider
class ModSlot : public juce::Component
{
public:
    ModSlot(APVTS& apvts, int slot, juce::Colour accent)
        : src(apvts, synthp::M1_SRC + slot * 3, ""), dst(apvts, synthp::M1_DST + slot * 3, ""),
          att(apvts, synthp::kParams[synthp::M1_AMT + slot * 3].id, amt)
    {
        amt.setSliderStyle(juce::Slider::LinearHorizontal);
        amt.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        amt.setColour(juce::Slider::trackColourId, accent);
        amt.setDoubleClickReturnValue(true, 0.0);
        amt.setTooltip("Mod amount");
        addAndMakeVisible(src); addAndMakeVisible(dst); addAndMakeVisible(amt);
        num = juce::String(slot + 1);
    }
    void paint(juce::Graphics& g) override
    {
        g.setColour(col::textDim); g.setFont(hudFont(10.0f, true));
        g.drawText(num, 0, 0, 12, getHeight(), juce::Justification::centred);
    }
    void resized() override
    {
        auto r = getLocalBounds(); r.removeFromLeft(14);
        const int cw = (int) ((float) r.getWidth() * 0.29f);
        src.setBounds(r.removeFromLeft(cw).reduced(1, 0)); dst.setBounds(r.removeFromLeft(cw + 6).reduced(1, 0));
        amt.setBounds(r.reduced(4, 0));
    }
    // ChoiceControl lays itself out with a label row; here we want the combo to fill the cell.
    struct Bare : ChoiceControl { using ChoiceControl::ChoiceControl; void resized() override { box.setBounds(getLocalBounds().reduced(1, 5)); } void paint(juce::Graphics&) override {} };
private:
    Bare src, dst;
    juce::Slider amt; juce::String num;
    APVTS::SliderAttachment att;
};

class Panel : public juce::Component
{
public:
    Panel(const juce::String& t, juce::Colour acc) : title(t), accent(acc) {}
    void setGrid(int c, int r, int rowHeader = 0) { cols = c; rows = r; rowHeaderH = rowHeader; }
    void place(juce::Component* c, int col, int row, int span = 1)
    {
        addAndMakeVisible(c); cells.push_back({ c, col, row, span });
    }
    void addGroup(int row, int col, int span, const juce::String& text) { groups.push_back({ row, col, span, text }); }
    void resized() override
    {
        const auto area = contentArea();
        const float cw = (float) area.getWidth() / (float) cols;
        const float ch = (float) area.getHeight() / (float) rows;
        for (auto& c : cells)
        {
            const int x = area.getX() + (int) (cw * (float) c.col), w = (int) (cw * (float) c.span);
            const int y = area.getY() + (int) (ch * (float) c.row) + rowHeaderH;
            c.comp->setBounds(x, y, w, (int) ch - rowHeaderH);
        }
    }
    void paint(juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced(0.5f);
        g.setColour(col::panel); g.fillRoundedRectangle(r, 4.0f);
        g.setColour(col::panelEdge); g.drawRoundedRectangle(r, 4.0f, 1.0f);
        // HUD corner brackets in accent colour
        g.setColour(accent.withAlpha(0.85f));
        const float L = 9.0f;
        juce::Path p;
        p.startNewSubPath(r.getX(), r.getY() + L); p.lineTo(r.getX(), r.getY()); p.lineTo(r.getX() + L, r.getY());
        p.startNewSubPath(r.getRight() - L, r.getBottom()); p.lineTo(r.getRight(), r.getBottom()); p.lineTo(r.getRight(), r.getBottom() - L);
        g.strokePath(p, juce::PathStrokeType(1.5f));
        g.setColour(accent); g.setFont(hudFont(10.5f, true));
        g.drawText(title, 10, 4, getWidth() - 20, 14, juce::Justification::centredLeft);
        g.setColour(accent.withAlpha(0.18f)); g.fillRect(10.0f, 19.0f, (float) getWidth() - 20.0f, 1.0f);
        if (rowHeaderH > 0)
        {
            const auto area = contentArea();
            const float cw = (float) area.getWidth() / (float) cols, ch = (float) area.getHeight() / (float) rows;
            for (auto& gr : groups)
            {
                const float x = (float) area.getX() + cw * (float) gr.col, y = (float) area.getY() + ch * (float) gr.row;
                g.setColour(col::textDim); g.setFont(hudFont(9.0f, true));
                g.drawText(gr.text, (int) x + 3, (int) y, (int) (cw * (float) gr.span) - 6, rowHeaderH, juce::Justification::centredLeft);
                g.setColour(col::panelEdge); g.fillRect(x + 2.0f, y + (float) rowHeaderH - 1.0f, cw * (float) gr.span - 4.0f, 1.0f);
            }
        }
    }
    juce::Rectangle<int> contentArea() const { return getLocalBounds().withTrimmedTop(22).reduced(6, 3); }
private:
    struct Cell { juce::Component* comp; int col, row, span; };
    struct Group { int row, col, span; juce::String text; };
    std::vector<Cell> cells; std::vector<Group> groups;
    juce::String title; juce::Colour accent; int cols = 1, rows = 1, rowHeaderH = 0;
};
}
