#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace ui
{
namespace col
{
const juce::Colour bg        { 0xff050508 };
const juce::Colour panel     { 0xff0a0a12 };
const juce::Colour panelEdge { 0xff1c1c2e };
const juce::Colour text      { 0xffa4adc8 };
const juce::Colour textDim   { 0xff575e7a };
const juce::Colour ice       { 0xff58dcff };
const juce::Colour violet    { 0xff9a5cff };
const juce::Colour red       { 0xffff2a58 };
const juce::Colour toxic     { 0xff7dffb2 };
}

inline juce::Font hudFont(float h, bool bold = false)
{
    return juce::Font(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), h, bold ? juce::Font::bold : juce::Font::plain));
}

class SynthLookAndFeel : public juce::LookAndFeel_V4
{
public:
    SynthLookAndFeel()
    {
        setColour(juce::ResizableWindow::backgroundColourId, col::bg);
        setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d0d18));
        setColour(juce::ComboBox::outlineColourId, col::panelEdge);
        setColour(juce::ComboBox::textColourId, col::text);
        setColour(juce::ComboBox::arrowColourId, col::ice);
        setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff0a0a14));
        setColour(juce::PopupMenu::textColourId, col::text);
        setColour(juce::PopupMenu::highlightedBackgroundColourId, col::ice.withAlpha(0.22f));
        setColour(juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
        setColour(juce::PopupMenu::headerTextColourId, col::violet);
        setColour(juce::TextButton::buttonColourId, juce::Colour(0xff0d0d18));
        setColour(juce::TextButton::textColourOffId, col::text);
        setColour(juce::TextButton::textColourOnId, col::ice);
        setColour(juce::Slider::rotarySliderFillColourId, col::ice);
        setColour(juce::Slider::trackColourId, col::ice);
        setColour(juce::Label::textColourId, col::text);
        setColour(juce::TooltipWindow::backgroundColourId, juce::Colour(0xff0a0a14));
        setColour(juce::TooltipWindow::textColourId, col::text);
        setColour(juce::TooltipWindow::outlineColourId, col::ice);
        setColour(juce::AlertWindow::backgroundColourId, juce::Colour(0xff0a0a14));
        setColour(juce::AlertWindow::textColourId, col::text);
        setColour(juce::AlertWindow::outlineColourId, col::ice);
        setColour(juce::TextEditor::backgroundColourId, juce::Colour(0xff050508));
        setColour(juce::TextEditor::textColourId, col::text);
        setColour(juce::TextEditor::outlineColourId, col::panelEdge);
        setColour(juce::TextEditor::focusedOutlineColourId, col::ice);
    }

    juce::Font getComboBoxFont(juce::ComboBox&) override { return hudFont(11.0f); }
    juce::Font getPopupMenuFont() override { return hudFont(12.0f); }
    juce::Font getLabelFont(juce::Label&) override { return hudFont(10.0f); }
    juce::Font getTextButtonFont(juce::TextButton&, int) override { return hudFont(11.0f, true); }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int w, int h, float pos, float a0, float a1, juce::Slider& s) override
    {
        auto bounds = juce::Rectangle<float>((float) x, (float) y, (float) w, (float) h).reduced(3.0f);
        const float d = std::min(bounds.getWidth(), bounds.getHeight());
        auto r = juce::Rectangle<float>(d, d).withCentre(bounds.getCentre());
        const auto accent = s.findColour(juce::Slider::rotarySliderFillColourId);
        const float thick = std::max(2.0f, d * 0.075f);
        const float arcR = d * 0.5f - thick * 0.5f - 0.5f;
        const auto c = r.getCentre();
        const bool bipolar = s.getMinimum() < 0.0 && s.getMaximum() > 0.0;
        const float angle = a0 + pos * (a1 - a0);

        // body
        auto body = r.reduced(thick + 2.0f);
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xff1a1a2a), body.getX(), body.getY(), juce::Colour(0xff08080f), body.getRight(), body.getBottom(), false));
        g.fillEllipse(body);
        g.setColour(col::panelEdge.brighter(0.2f));
        g.drawEllipse(body, 1.0f);

        // track
        juce::Path track; track.addCentredArc(c.x, c.y, arcR, arcR, 0.0f, a0, a1, true);
        g.setColour(juce::Colour(0xff15151f));
        g.strokePath(track, juce::PathStrokeType(thick, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // value arc + glow
        const float from = bipolar ? a0 + 0.5f * (a1 - a0) : a0;
        juce::Path val; val.addCentredArc(c.x, c.y, arcR, arcR, 0.0f, std::min(from, angle), std::max(from, angle), true);
        if (s.isEnabled())
        {
            for (int i = 3; i >= 1; --i)
            {
                g.setColour(accent.withAlpha(0.07f * (float) (4 - i)));
                g.strokePath(val, juce::PathStrokeType(thick + (float) i * 2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }
            g.setColour(accent);
            g.strokePath(val, juce::PathStrokeType(thick, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        // pointer
        juce::Path p;
        const float len = body.getWidth() * 0.5f;
        p.startNewSubPath(0.0f, -len * 0.25f); p.lineTo(0.0f, -len * 0.92f);
        g.setColour(juce::Colours::white.withAlpha(0.92f));
        g.strokePath(p, juce::PathStrokeType(std::max(1.5f, d * 0.04f), juce::PathStrokeType::curved, juce::PathStrokeType::rounded),
                     juce::AffineTransform::rotation(angle).translated(c.x, c.y));
    }

    void drawLinearSlider(juce::Graphics& g, int x, int y, int w, int h, float pos, float, float, juce::Slider::SliderStyle, juce::Slider& s) override
    {
        const auto accent = s.findColour(juce::Slider::trackColourId);
        const float cy = (float) y + (float) h * 0.5f;
        const float x0 = (float) x + 2.0f, x1 = (float) (x + w) - 2.0f;
        g.setColour(juce::Colour(0xff15151f));
        g.fillRoundedRectangle(x0, cy - 2.0f, x1 - x0, 4.0f, 2.0f);
        const bool bipolar = s.getMinimum() < 0.0;
        const float from = bipolar ? (x0 + x1) * 0.5f : x0;
        const float vx = juce::jlimit(x0, x1, pos);
        g.setColour(accent.withAlpha(0.25f));
        g.fillRoundedRectangle(std::min(from, vx), cy - 4.0f, std::abs(vx - from), 8.0f, 3.0f);
        g.setColour(accent);
        g.fillRoundedRectangle(std::min(from, vx), cy - 2.0f, std::abs(vx - from), 4.0f, 2.0f);
        if (bipolar) { g.setColour(col::textDim); g.fillRect((x0 + x1) * 0.5f - 0.5f, cy - 5.0f, 1.0f, 10.0f); }
        g.setColour(juce::Colours::white);
        g.fillEllipse(vx - 4.0f, cy - 4.0f, 8.0f, 8.0f);
    }

    void drawComboBox(juce::Graphics& g, int w, int h, bool, int, int, int, int, juce::ComboBox& box) override
    {
        auto r = juce::Rectangle<float>(0.5f, 0.5f, (float) w - 1.0f, (float) h - 1.0f);
        g.setColour(juce::Colour(0xff0d0d18));
        g.fillRoundedRectangle(r, 3.0f);
        g.setColour(box.hasKeyboardFocus(true) ? col::ice : col::panelEdge.brighter(0.15f));
        g.drawRoundedRectangle(r, 3.0f, 1.0f);
        juce::Path arrow;
        const float ax = (float) w - 11.0f, ay = (float) h * 0.5f;
        arrow.addTriangle(ax - 3.5f, ay - 2.0f, ax + 3.5f, ay - 2.0f, ax, ay + 2.5f);
        g.setColour(col::ice.withAlpha(box.isEnabled() ? 0.9f : 0.3f));
        g.fillPath(arrow);
    }
    void positionComboBoxText(juce::ComboBox& box, juce::Label& label) override
    {
        label.setBounds(4, 1, box.getWidth() - 18, box.getHeight() - 2);
        label.setFont(getComboBoxFont(box));
        label.setJustificationType(juce::Justification::centredLeft);
    }

    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& b, bool hover, bool) override
    {
        auto r = b.getLocalBounds().toFloat();
        const float d = std::min(r.getHeight(), 14.0f);
        auto led = juce::Rectangle<float>(d, d).withCentre(r.getCentre());
        const auto accent = b.findColour(juce::ToggleButton::tickColourId);
        if (b.getToggleState())
        {
            g.setColour(accent.withAlpha(0.25f)); g.fillEllipse(led.expanded(3.0f));
            g.setColour(accent); g.fillEllipse(led);
        }
        else { g.setColour(juce::Colour(0xff15151f)); g.fillEllipse(led); }
        g.setColour(hover ? col::ice : col::panelEdge.brighter(0.3f)); g.drawEllipse(led, 1.0f);
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& b, const juce::Colour&, bool hover, bool down) override
    {
        auto r = b.getLocalBounds().toFloat().reduced(0.5f);
        g.setColour(down ? col::ice.withAlpha(0.25f) : juce::Colour(0xff0d0d18));
        g.fillRoundedRectangle(r, 3.0f);
        g.setColour(hover ? col::ice : col::panelEdge.brighter(0.2f));
        g.drawRoundedRectangle(r, 3.0f, 1.0f);
    }
};
}
