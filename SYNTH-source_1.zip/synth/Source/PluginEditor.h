#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "UI/Look.h"
#include "UI/Widgets.h"
#include "UI/Displays.h"
#include <memory>
#include <vector>

class SynthAudioProcessorEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit SynthAudioProcessorEditor(SynthAudioProcessor&);
    ~SynthAudioProcessorEditor() override;

    void resized() override;
    void parentHierarchyChanged() override;
    void paint(juce::Graphics&) override {}

    static constexpr int kBaseW = 1180, kBaseH = 780;

private:
    // The whole UI lives in a fixed-size content component that is scaled to the window size.
    class Content : public juce::Component
    {
    public:
        void paint(juce::Graphics& g) override;
        juce::Image noise;
        juce::String presetLabel;
        int voices = 0;
    };

    void timerCallback() override;
    void buildUI();
    void layoutContent();
    void rebuildPresetMenu();
    void promptSavePreset();

    template <typename T, typename... Args> T& make(Args&&... args)
    {
        auto p = std::make_unique<T>(std::forward<Args>(args)...);
        T& ref = *p; owned.push_back(std::move(p)); return ref;
    }
    struct Holder { virtual ~Holder() = default; };
    template <typename T> struct Box : Holder { std::unique_ptr<T> p; explicit Box(std::unique_ptr<T> q) : p(std::move(q)) {} };
    std::vector<std::unique_ptr<juce::Component>> owned;

    SynthAudioProcessor& proc;
    ui::SynthLookAndFeel laf;
    Content content;
    juce::TooltipWindow tooltip { this, 700 };

    ui::Panel *pOsc1 = nullptr, *pOsc2 = nullptr, *pSub = nullptr, *pDisp = nullptr, *pFilter = nullptr, *pAmp = nullptr, *pEnv2 = nullptr,
              *pLfo = nullptr, *pVoice = nullptr, *pMod = nullptr, *pMacro = nullptr, *pFx = nullptr;
    ui::WavetableView* wtView = nullptr; ui::ScopeView* scopeView = nullptr; ui::SpectrumView* specView = nullptr;
    juce::ComboBox presetBox; juce::TextButton prevBtn { "<" }, nextBtn { ">" }, saveBtn { "SAVE" };
    ui::KnobControl *masterKnob = nullptr, *widthKnob = nullptr;
    std::vector<juce::File> userPresets;
    int lastVoices = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SynthAudioProcessorEditor)
};
