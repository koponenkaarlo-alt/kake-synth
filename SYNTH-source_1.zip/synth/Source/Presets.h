#pragma once
#include "Params.h"

namespace presets
{
int count();
const char* name(int index);
const char* category(int index);
void load(int index, float* paramsOut);      // fills NUM_PARAMS real values: defaults + overrides
int validate();                              // number of unknown parameter ids in the factory bank (must be 0)
}
