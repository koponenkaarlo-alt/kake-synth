#include "Presets.h"
#include <vector>
#include <utility>
#include <cstdio>

namespace presets
{
namespace
{
using KV = std::pair<const char*, float>;
struct Preset { const char* name; const char* cat; std::vector<KV> v; };

// wavetable helper: table index -> 0..1 position
constexpr float T(int i) { return (float) i / 11.0f; }
enum { SOFT = 0, BELL = 1, CHOIR = 2, FLUTE = 3, SAW = 4, PLUCK = 5, REESE = 6, RAGE = 7, LOFI = 8, METAL = 9, DUST = 10, OH = 11 };
// filter types: LP12 0, Ladder 1, HP 2, BP 3, Notch 4.  mod src: 1 LFO1, 2 LFO2, 3 Env2, 4 Vel, 5 Wheel, 6 AT, 7 Key, 8 Rand
// mod dst: 1 Pitch, 2 Tab1, 3 Tab2, 4 Cutoff, 5 Reso, 6 Amp, 7 Pan, 8 FM, 9 Drive, 10 Detune

const std::vector<Preset>& bank()
{
    static const std::vector<Preset> b = {
    // ------------------------------------------------------------ PADS
    { "Init", "Pads", { { "o1_table", T(SAW) }, { "o1_uni", 1 }, { "f1_cut", 12000 }, { "amp_a", 0.005f }, { "amp_r", 0.2f } } },
    { "Fog Machine", "Pads", {
        { "o1_table", T(SAW) }, { "o1_uni", 5 }, { "o1_detune", 0.32f }, { "o1_level", 0.7f },
        { "o2_table", T(FLUTE) }, { "o2_level", 0.45f }, { "o2_oct", 0 }, { "o2_detune", 0.2f }, { "o2_uni", 3 },
        { "f1_cut", 1900 }, { "f1_res", 0.18f }, { "amp_a", 1.1f }, { "amp_d", 1.0f }, { "amp_s", 0.85f }, { "amp_r", 3.2f },
        { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.12f }, { "l1_rate", 0.18f },
        { "cho_mix", 0.45f }, { "tape_amt", 0.3f }, { "rev_mix", 0.5f }, { "rev_decay", 0.7f }, { "rev_shim", 0.2f }, { "drift", 0.4f } } },
    { "Static Heaven", "Pads", {
        { "o1_table", T(CHOIR) }, { "o1_uni", 5 }, { "o1_detune", 0.2f }, { "o2_table", T(OH) }, { "o2_level", 0.5f }, { "o2_uni", 3 },
        { "f1_cut", 3500 }, { "f1_res", 0.1f }, { "amp_a", 0.9f }, { "amp_s", 0.9f }, { "amp_r", 3.5f },
        { "m1_src", 1 }, { "m1_dst", 3 }, { "m1_amt", 0.3f }, { "l1_rate", 0.12f },
        { "rev_mix", 0.6f }, { "rev_decay", 0.85f }, { "rev_shim", 0.5f }, { "cho_mix", 0.3f }, { "dly_mix", 0.18f }, { "dly_div", 2 } } },
    { "Lost In The Void", "Pads", {
        { "o1_table", T(REESE) }, { "o1_uni", 7 }, { "o1_detune", 0.35f }, { "o2_table", T(SOFT) }, { "o2_level", 0.4f }, { "o2_oct", -1 },
        { "f1_cut", 900 }, { "f1_res", 0.25f }, { "amp_a", 1.6f }, { "amp_s", 0.9f }, { "amp_r", 4.5f },
        { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.2f }, { "l1_rate", 0.09f }, { "m2_src", 2 }, { "m2_dst", 2 }, { "m2_amt", 0.15f },
        { "rev_mix", 0.55f }, { "rev_decay", 0.92f }, { "rev_damp", 0.75f }, { "uw_cut", 6500 }, { "tape_amt", 0.25f } } },
    { "Dead Roses", "Pads", {
        { "o1_table", T(FLUTE) }, { "o1_uni", 3 }, { "o1_detune", 0.25f }, { "o2_table", T(SOFT) }, { "o2_level", 0.5f },
        { "f1_cut", 2600 }, { "amp_a", 0.5f }, { "amp_s", 0.8f }, { "amp_r", 2.4f },
        { "tape_amt", 0.55f }, { "tape_noise", 0.25f }, { "tape_tone", 6500 }, { "cho_mix", 0.4f }, { "rev_mix", 0.45f }, { "drift", 0.55f } } },
    { "Cold Ambience", "Pads", {
        { "o1_table", T(BELL) }, { "o1_uni", 3 }, { "o2_table", T(CHOIR) }, { "o2_level", 0.6f }, { "o2_uni", 3 },
        { "f1_cut", 4200 }, { "amp_a", 1.4f }, { "amp_s", 0.85f }, { "amp_r", 3.0f },
        { "dly_mix", 0.3f }, { "dly_div", 2 }, { "dly_fb", 0.55f }, { "dly_tone", 2500 }, { "rev_mix", 0.55f }, { "rev_decay", 0.8f }, { "rev_shim", 0.35f } } },
    { "Purple Rain Haze", "Pads", {
        { "o1_table", T(SAW) }, { "o1_uni", 7 }, { "o1_detune", 0.45f }, { "o1_spread", 1.0f }, { "o2_table", T(LOFI) }, { "o2_level", 0.3f },
        { "f1_cut", 1500 }, { "f1_res", 0.2f }, { "amp_a", 0.7f }, { "amp_s", 0.85f }, { "amp_r", 2.6f },
        { "l1_sync", 1 }, { "l1_div", 1 }, { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.22f },
        { "cho_mix", 0.5f }, { "cho_rate", 0.25f }, { "rev_mix", 0.4f }, { "mac_haze", 0.2f } } },
    { "Sleepwalker", "Pads", {
        { "o1_table", T(LOFI) }, { "o1_uni", 3 }, { "o1_detune", 0.3f }, { "o2_table", T(SAW) }, { "o2_level", 0.35f }, { "o2_oct", -1 },
        { "f1_cut", 1300 }, { "amp_a", 0.6f }, { "amp_s", 0.85f }, { "amp_r", 2.2f }, { "drift", 0.85f },
        { "tape_amt", 0.7f }, { "tape_tone", 5000 }, { "cho_mix", 0.35f }, { "rev_mix", 0.4f }, { "rev_decay", 0.65f } } },
    { "Ghost Choir", "Pads", {
        { "o1_table", T(OH) }, { "o1_uni", 5 }, { "o1_detune", 0.22f }, { "o2_table", T(CHOIR) }, { "o2_level", 0.7f }, { "o2_uni", 5 }, { "o2_detune", 0.3f },
        { "f1_cut", 2800 }, { "amp_a", 1.8f }, { "amp_s", 0.9f }, { "amp_r", 4.0f },
        { "rev_mix", 0.6f }, { "rev_decay", 0.88f }, { "rev_shim", 0.65f }, { "cho_mix", 0.25f }, { "uw_cut", 9000 } } },
    // ------------------------------------------------------------ BELLS
    { "Glass Angel", "Bells", {
        { "o1_table", T(BELL) }, { "o1_uni", 2 }, { "o1_detune", 0.15f }, { "o2_table", T(SOFT) }, { "o2_oct", 1 }, { "o2_level", 0.25f }, { "fm_amt", 0.25f },
        { "f1_type", 0 }, { "f1_cut", 9000 }, { "amp_a", 0.002f }, { "amp_d", 1.6f }, { "amp_s", 0.0f }, { "amp_r", 1.4f },
        { "dly_mix", 0.28f }, { "dly_div", 2 }, { "dly_fb", 0.5f }, { "rev_mix", 0.5f }, { "rev_decay", 0.75f }, { "rev_shim", 0.3f } } },
    { "Nokia Bells", "Bells", {
        { "o1_table", T(PLUCK) }, { "o1_uni", 1 }, { "o2_table", T(BELL) }, { "o2_level", 0.4f }, { "o2_oct", 1 },
        { "f1_cut", 7000 }, { "amp_a", 0.001f }, { "amp_d", 0.45f }, { "amp_s", 0.0f }, { "amp_r", 0.3f },
        { "crush_mix", 0.35f }, { "crush_bits", 9 }, { "crush_rate", 3 }, { "dly_mix", 0.22f }, { "dly_div", 3 }, { "rev_mix", 0.25f } } },
    { "Snowglobe", "Bells", {
        { "o1_table", T(BELL) }, { "o2_table", T(BELL) }, { "o2_semi", 12 }, { "o2_level", 0.4f }, { "ring_amt", 0.18f },
        { "f1_type", 0 }, { "f1_cut", 11000 }, { "amp_a", 0.003f }, { "amp_d", 2.2f }, { "amp_s", 0.0f }, { "amp_r", 2.0f },
        { "rev_mix", 0.6f }, { "rev_decay", 0.85f }, { "rev_shim", 0.6f }, { "cho_mix", 0.2f } } },
    { "Ice Cathedral", "Bells", {
        { "o1_table", T(METAL) }, { "o1_uni", 2 }, { "o1_detune", 0.1f }, { "o2_table", T(SOFT) }, { "o2_level", 0.3f }, { "fm_amt", 0.4f },
        { "f1_cut", 6500 }, { "amp_a", 0.004f }, { "amp_d", 2.4f }, { "amp_s", 0.0f }, { "amp_r", 2.4f },
        { "rev_mix", 0.6f }, { "rev_decay", 0.9f }, { "rev_damp", 0.6f }, { "dly_mix", 0.2f } } },
    { "Music Box Ghost", "Bells", {
        { "o1_table", T(PLUCK) }, { "o2_table", T(SOFT) }, { "o2_oct", 1 }, { "o2_level", 0.35f },
        { "f1_cut", 5500 }, { "amp_a", 0.001f }, { "amp_d", 0.9f }, { "amp_s", 0.0f }, { "amp_r", 0.9f },
        { "tape_amt", 0.65f }, { "tape_noise", 0.4f }, { "tape_tone", 5500 }, { "rev_mix", 0.4f }, { "drift", 0.6f } } },
    { "Tin Angel", "Bells", {
        { "o1_table", T(METAL) }, { "o2_table", T(BELL) }, { "o2_level", 0.5f }, { "o2_oct", 1 },
        { "f1_type", 2 }, { "f1_cut", 700 }, { "amp_a", 0.001f }, { "amp_d", 0.8f }, { "amp_s", 0.0f }, { "amp_r", 0.8f },
        { "dly_mix", 0.3f }, { "dly_div", 4 }, { "rev_mix", 0.35f }, { "uw_cut", 12000 } } },
    // ------------------------------------------------------------ LEADS
    { "Rage Cathedral", "Leads", {
        { "o1_table", T(RAGE) }, { "o1_uni", 5 }, { "o1_detune", 0.5f }, { "o2_table", T(SAW) }, { "o2_level", 0.4f }, { "o2_oct", -1 },
        { "f1_cut", 3800 }, { "f1_res", 0.25f }, { "f1_drive", 0.3f }, { "voice_mode", 2 }, { "glide", 0.06f },
        { "amp_a", 0.004f }, { "amp_s", 0.85f }, { "amp_r", 0.5f },
        { "dist_mix", 0.6f }, { "dist_drive", 0.45f }, { "rev_mix", 0.3f }, { "rev_decay", 0.7f }, { "dly_mix", 0.15f } } },
    { "Whole Lotta Synth", "Leads", {
        { "o1_table", T(RAGE) }, { "o1_uni", 3 }, { "o1_detune", 0.35f }, { "o2_table", T(LOFI) }, { "o2_level", 0.45f },
        { "f1_cut", 5200 }, { "f1_res", 0.2f }, { "voice_mode", 1 }, { "glide", 0.03f }, { "amp_a", 0.002f }, { "amp_s", 0.9f }, { "amp_r", 0.2f },
        { "dist_mix", 0.75f }, { "dist_type", 1 }, { "dist_drive", 0.5f }, { "crush_mix", 0.25f }, { "crush_bits", 10 }, { "rev_mix", 0.15f } } },
    { "Void Walker", "Leads", {
        { "o1_table", T(REESE) }, { "o1_uni", 3 }, { "o1_detune", 0.25f }, { "o2_table", T(SAW) }, { "o2_level", 0.3f },
        { "f1_cut", 700 }, { "f1_res", 0.3f }, { "f1_env", 0.55f }, { "voice_mode", 2 }, { "glide", 0.1f },
        { "env2_a", 0.01f }, { "env2_d", 0.5f }, { "env2_s", 0.15f }, { "amp_a", 0.01f }, { "amp_s", 0.85f }, { "amp_r", 0.6f },
        { "dist_mix", 0.35f }, { "rev_mix", 0.4f }, { "rev_decay", 0.8f }, { "dly_mix", 0.2f }, { "dly_div", 2 } } },
    { "Neon Graveyard", "Leads", {
        { "o1_table", T(PLUCK) }, { "o1_uni", 3 }, { "o1_detune", 0.2f }, { "o2_table", T(SAW) }, { "o2_level", 0.4f }, { "o2_uni", 3 }, { "o2_detune", 0.3f },
        { "f1_cut", 4200 }, { "f1_res", 0.22f }, { "amp_a", 0.004f }, { "amp_s", 0.75f }, { "amp_r", 0.7f },
        { "m1_src", 1 }, { "m1_dst", 1 }, { "m1_amt", 0.012f }, { "l1_rate", 5.2f },
        { "cho_mix", 0.4f }, { "dly_mix", 0.3f }, { "dly_div", 4 }, { "rev_mix", 0.4f }, { "rev_decay", 0.75f } } },
    { "Plugg Flute", "Leads", {
        { "o1_table", T(FLUTE) }, { "o2_table", T(SOFT) }, { "o2_level", 0.5f }, { "o2_oct", 1 },
        { "f1_type", 0 }, { "f1_cut", 3800 }, { "f1_env", 0.25f }, { "env2_d", 0.3f }, { "env2_s", 0.0f },
        { "amp_a", 0.003f }, { "amp_d", 0.55f }, { "amp_s", 0.1f }, { "amp_r", 0.5f },
        { "m1_src", 1 }, { "m1_dst", 1 }, { "m1_amt", 0.008f }, { "l1_rate", 5.5f },
        { "dly_mix", 0.28f }, { "dly_div", 3 }, { "dly_fb", 0.45f }, { "rev_mix", 0.4f }, { "rev_decay", 0.7f } } },
    { "Cloud Lead", "Leads", {
        { "o1_table", T(SAW) }, { "o1_uni", 3 }, { "o1_detune", 0.3f }, { "o2_table", T(LOFI) }, { "o2_level", 0.3f },
        { "f1_cut", 4800 }, { "f1_res", 0.12f }, { "amp_a", 0.02f }, { "amp_s", 0.8f }, { "amp_r", 1.0f },
        { "m1_src", 1 }, { "m1_dst", 1 }, { "m1_amt", 0.01f }, { "l1_rate", 4.6f },
        { "cho_mix", 0.4f }, { "dly_mix", 0.28f }, { "dly_div", 2 }, { "rev_mix", 0.5f }, { "rev_decay", 0.75f }, { "mac_haze", 0.15f } } },
    { "Glitch Prophet", "Leads", {
        { "o1_table", T(METAL) }, { "o1_uni", 2 }, { "o2_table", T(PLUCK) }, { "o2_level", 0.4f }, { "fm_amt", 0.35f },
        { "f1_cut", 4500 }, { "f1_res", 0.3f }, { "amp_a", 0.002f }, { "amp_d", 0.5f }, { "amp_s", 0.5f }, { "amp_r", 0.4f },
        { "l1_shape", 4 }, { "l1_sync", 1 }, { "l1_div", 4 }, { "m1_src", 1 }, { "m1_dst", 2 }, { "m1_amt", 0.5f }, { "m2_src", 1 }, { "m2_dst", 4 }, { "m2_amt", 0.2f },
        { "crush_mix", 0.3f }, { "crush_bits", 8 }, { "dly_mix", 0.3f }, { "dly_div", 6 }, { "rev_mix", 0.3f } } },
    // ------------------------------------------------------------ PLUCKS
    { "Dark Pluck", "Plucks", {
        { "o1_table", T(SAW) }, { "o1_uni", 3 }, { "o1_detune", 0.15f }, { "o2_table", T(FLUTE) }, { "o2_level", 0.3f },
        { "f1_cut", 700 }, { "f1_res", 0.2f }, { "f1_env", 0.6f }, { "env2_d", 0.25f }, { "env2_s", 0.0f },
        { "amp_a", 0.001f }, { "amp_d", 0.35f }, { "amp_s", 0.0f }, { "amp_r", 0.3f }, { "rev_mix", 0.35f }, { "dly_mix", 0.18f }, { "dly_div", 3 } } },
    { "Lofi Kalimba", "Plucks", {
        { "o1_table", T(SOFT) }, { "o2_table", T(BELL) }, { "o2_level", 0.4f }, { "o2_oct", 1 }, { "f1_type", 0 }, { "f1_cut", 4500 },
        { "amp_a", 0.001f }, { "amp_d", 0.6f }, { "amp_s", 0.0f }, { "amp_r", 0.5f },
        { "tape_amt", 0.55f }, { "tape_noise", 0.3f }, { "tape_tone", 6000 }, { "rev_mix", 0.3f }, { "drift", 0.5f } } },
    { "Static Pluck", "Plucks", {
        { "o1_table", T(PLUCK) }, { "o2_table", T(LOFI) }, { "o2_level", 0.4f }, { "f1_cut", 3000 }, { "f1_env", 0.4f }, { "env2_d", 0.2f }, { "env2_s", 0.0f },
        { "amp_a", 0.001f }, { "amp_d", 0.28f }, { "amp_s", 0.0f }, { "amp_r", 0.2f },
        { "l1_shape", 4 }, { "l1_rate", 9 }, { "m1_src", 1 }, { "m1_dst", 2 }, { "m1_amt", 0.3f }, { "crush_mix", 0.2f }, { "crush_bits", 11 }, { "dly_mix", 0.2f } } },
    { "Blade Pluck", "Plucks", {
        { "o1_table", T(RAGE) }, { "o1_uni", 3 }, { "o1_detune", 0.3f }, { "f1_cut", 1200 }, { "f1_res", 0.25f }, { "f1_env", 0.6f }, { "env2_d", 0.18f }, { "env2_s", 0.0f },
        { "amp_a", 0.001f }, { "amp_d", 0.3f }, { "amp_s", 0.0f }, { "amp_r", 0.2f }, { "dist_mix", 0.4f }, { "dist_drive", 0.4f }, { "rev_mix", 0.25f } } },
    { "Ghost Marimba", "Plucks", {
        { "o1_table", T(FLUTE) }, { "o2_table", T(BELL) }, { "o2_level", 0.35f }, { "o2_oct", 1 }, { "f1_type", 0 }, { "f1_cut", 3500 },
        { "amp_a", 0.001f }, { "amp_d", 0.4f }, { "amp_s", 0.0f }, { "amp_r", 0.35f }, { "cho_mix", 0.3f }, { "rev_mix", 0.45f }, { "rev_shim", 0.2f } } },
    // ------------------------------------------------------------ 808 / BASS
    { "Cold Sweat 808", "808/Bass", {
        { "o1_table", T(SOFT) }, { "o1_uni", 1 }, { "o1_level", 0.85f }, { "sub_level", 0.4f }, { "o2_level", 0.0f },
        { "f1_type", 1 }, { "f1_cut", 900 }, { "f1_res", 0.05f }, { "voice_mode", 2 }, { "glide", 0.08f },
        { "amp_a", 0.001f }, { "amp_d", 2.6f }, { "amp_s", 0.0f }, { "amp_r", 0.25f }, { "dist_mix", 0.3f }, { "dist_drive", 0.2f } } },
    { "Black Ice 808", "808/Bass", {
        { "o1_table", T(SOFT) }, { "o1_level", 0.85f }, { "o1_uni", 1 }, { "sub_level", 0.35f }, { "o2_level", 0.0f },
        { "f1_cut", 1400 }, { "f1_res", 0.08f }, { "voice_mode", 2 }, { "glide", 0.09f }, { "env2_a", 0.001f }, { "env2_d", 0.07f }, { "env2_s", 0.0f },
        { "m1_src", 3 }, { "m1_dst", 1 }, { "m1_amt", 0.3f }, { "amp_a", 0.001f }, { "amp_d", 2.2f }, { "amp_s", 0.0f }, { "amp_r", 0.2f },
        { "dist_mix", 0.55f }, { "dist_drive", 0.45f }, { "dist_type", 0 } } },
    { "Reese Rain", "808/Bass", {
        { "o1_table", T(REESE) }, { "o1_uni", 5 }, { "o1_detune", 0.5f }, { "o1_spread", 0.4f }, { "o2_table", T(SOFT) }, { "o2_level", 0.5f }, { "o2_oct", -1 },
        { "f1_cut", 450 }, { "f1_res", 0.2f }, { "amp_a", 0.005f }, { "amp_s", 0.9f }, { "amp_r", 0.4f },
        { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.18f }, { "l1_rate", 0.4f }, { "dist_mix", 0.25f }, { "rev_mix", 0.15f } } },
    { "Distorted Sub", "808/Bass", {
        { "o1_table", T(SOFT) }, { "o1_level", 0.8f }, { "sub_level", 0.5f }, { "f1_cut", 1500 }, { "voice_mode", 2 }, { "glide", 0.05f },
        { "amp_a", 0.001f }, { "amp_d", 1.8f }, { "amp_s", 0.0f }, { "amp_r", 0.2f },
        { "dist_mix", 0.8f }, { "dist_type", 1 }, { "dist_drive", 0.55f }, { "crush_mix", 0.15f }, { "crush_bits", 10 } } },
    { "Sleepy Sub", "808/Bass", {
        { "o1_table", T(SOFT) }, { "o1_level", 0.8f }, { "sub_level", 0.5f }, { "sub_wave", 1 }, { "voice_mode", 2 }, { "glide", 0.16f },
        { "f1_cut", 700 }, { "amp_a", 0.01f }, { "amp_d", 1.2f }, { "amp_s", 0.6f }, { "amp_r", 0.4f }, { "tape_amt", 0.3f }, { "rev_mix", 0.1f } } },
    { "Rage Bass", "808/Bass", {
        { "o1_table", T(RAGE) }, { "o1_uni", 3 }, { "o1_detune", 0.3f }, { "sub_level", 0.5f }, { "f1_cut", 900 }, { "f1_res", 0.3f }, { "f1_drive", 0.4f },
        { "voice_mode", 1 }, { "glide", 0.03f }, { "amp_a", 0.002f }, { "amp_s", 0.9f }, { "amp_r", 0.2f },
        { "dist_mix", 0.6f }, { "dist_type", 2 }, { "dist_drive", 0.4f } } },
    // ------------------------------------------------------------ TEXTURES
    { "Dust Storm", "Textures", {
        { "o1_table", T(DUST) }, { "o1_uni", 5 }, { "o1_detune", 0.4f }, { "noise_level", 0.35f }, { "noise_tone", 0.4f },
        { "f1_cut", 2200 }, { "f1_res", 0.25f }, { "amp_a", 2.0f }, { "amp_s", 0.9f }, { "amp_r", 4.0f },
        { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.3f }, { "l1_rate", 0.11f }, { "tape_amt", 0.4f }, { "tape_noise", 0.55f }, { "rev_mix", 0.45f } } },
    { "Server Room", "Textures", {
        { "o1_table", T(METAL) }, { "o1_uni", 3 }, { "o1_level", 1.0f }, { "noise_level", 0.3f }, { "f1_type", 3 }, { "f1_cut", 1800 }, { "f1_res", 0.35f }, { "master_vol", 1.0f },
        { "amp_a", 0.6f }, { "amp_s", 0.9f }, { "amp_r", 2.0f }, { "l1_shape", 4 }, { "l1_sync", 1 }, { "l1_div", 4 }, { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.4f },
        { "dly_mix", 0.35f }, { "dly_div", 6 }, { "dly_fb", 0.55f }, { "rev_mix", 0.3f } } },
    { "Underwater Choir", "Textures", {
        { "o1_table", T(CHOIR) }, { "o1_uni", 5 }, { "o1_detune", 0.25f }, { "o2_table", T(OH) }, { "o2_level", 0.5f },
        { "f1_cut", 2400 }, { "amp_a", 1.4f }, { "amp_s", 0.9f }, { "amp_r", 3.5f }, { "uw_cut", 950 }, { "cho_mix", 0.4f }, { "rev_mix", 0.55f }, { "rev_decay", 0.85f } } },
    { "Broken Cassette", "Textures", {
        { "o1_table", T(LOFI) }, { "o1_uni", 3 }, { "o1_detune", 0.3f }, { "f1_cut", 2200 }, { "amp_a", 0.4f }, { "amp_s", 0.85f }, { "amp_r", 2.0f },
        { "drift", 1.0f }, { "tape_amt", 1.0f }, { "tape_noise", 0.6f }, { "tape_tone", 4200 }, { "crush_mix", 0.3f }, { "crush_bits", 9 }, { "crush_rate", 4 }, { "rev_mix", 0.3f } } },
    { "Tundra", "Textures", {
        { "o1_table", T(SOFT) }, { "o1_level", 0.35f }, { "noise_level", 0.5f }, { "noise_tone", 0.7f }, { "f1_type", 2 }, { "f1_cut", 400 }, { "f1_res", 0.2f },
        { "amp_a", 2.5f }, { "amp_s", 0.9f }, { "amp_r", 5.0f }, { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.35f }, { "l1_rate", 0.07f },
        { "rev_mix", 0.6f }, { "rev_decay", 0.9f }, { "rev_shim", 0.4f } } },
    { "Radio Static", "Textures", {
        { "o1_level", 0.0f }, { "noise_level", 1.0f }, { "noise_tone", 0.6f }, { "f1_type", 3 }, { "f1_cut", 2500 }, { "f1_res", 0.4f }, { "master_vol", 1.0f },
        { "amp_a", 0.3f }, { "amp_s", 0.9f }, { "amp_r", 1.5f }, { "l1_shape", 5 }, { "l1_rate", 2.5f }, { "m1_src", 1 }, { "m1_dst", 4 }, { "m1_amt", 0.5f },
        { "tape_noise", 0.5f }, { "crush_mix", 0.4f }, { "crush_bits", 7 }, { "rev_mix", 0.25f } } },
    // ------------------------------------------------------------ RAGE
    { "Rage Alarm", "Rage", {
        { "o1_table", T(RAGE) }, { "o1_uni", 7 }, { "o1_detune", 0.8f }, { "o2_table", T(LOFI) }, { "o2_level", 0.4f },
        { "f1_cut", 6500 }, { "f1_res", 0.2f }, { "voice_mode", 1 }, { "glide", 0.02f }, { "amp_a", 0.002f }, { "amp_s", 0.9f }, { "amp_r", 0.15f },
        { "dist_mix", 0.8f }, { "dist_type", 1 }, { "dist_drive", 0.7f }, { "crush_mix", 0.2f }, { "crush_bits", 9 } } },
    { "Blood Moon", "Rage", {
        { "o1_table", T(RAGE) }, { "o1_uni", 5 }, { "o1_detune", 0.55f }, { "o2_table", T(REESE) }, { "o2_level", 0.55f }, { "o2_oct", -1 },
        { "f1_cut", 2600 }, { "f1_res", 0.3f }, { "f1_drive", 0.3f }, { "amp_a", 0.01f }, { "amp_s", 0.85f }, { "amp_r", 0.6f },
        { "dist_mix", 0.6f }, { "dist_type", 2 }, { "dist_drive", 0.5f }, { "rev_mix", 0.35f }, { "rev_decay", 0.8f }, { "uw_cut", 7000 } } },
    { "Scream Choir", "Rage", {
        { "o1_table", T(CHOIR) }, { "o1_uni", 5 }, { "o1_detune", 0.3f }, { "o2_table", T(RAGE) }, { "o2_level", 0.5f }, { "o2_uni", 3 },
        { "f1_cut", 3500 }, { "amp_a", 0.3f }, { "amp_s", 0.9f }, { "amp_r", 1.5f },
        { "dist_mix", 0.55f }, { "dist_drive", 0.5f }, { "rev_mix", 0.5f }, { "rev_shim", 0.3f } } },
    { "Trench Coat", "Rage", {
        { "o1_table", T(RAGE) }, { "o1_uni", 3 }, { "o1_detune", 0.4f }, { "o2_table", T(SAW) }, { "o2_level", 0.4f }, { "o2_semi", 7 },
        { "f1_cut", 3000 }, { "f1_res", 0.22f }, { "voice_mode", 2 }, { "glide", 0.05f }, { "amp_a", 0.003f }, { "amp_s", 0.85f }, { "amp_r", 0.3f },
        { "dist_mix", 0.5f }, { "dist_drive", 0.4f }, { "dly_mix", 0.2f }, { "dly_div", 3 }, { "rev_mix", 0.25f } } },
    { "Lil Ghost", "Rage", {
        { "o1_table", T(LOFI) }, { "o1_uni", 3 }, { "o1_detune", 0.25f }, { "o2_table", T(BELL) }, { "o2_level", 0.35f }, { "o2_oct", 1 },
        { "f1_cut", 3800 }, { "amp_a", 0.005f }, { "amp_d", 0.6f }, { "amp_s", 0.5f }, { "amp_r", 0.8f },
        { "tape_amt", 0.4f }, { "dist_mix", 0.3f }, { "cho_mix", 0.3f }, { "dly_mix", 0.25f }, { "dly_div", 4 }, { "rev_mix", 0.4f }, { "mac_haze", 0.2f } } },
    };
    return b;
}
}

int count() { return (int) bank().size(); }
const char* name(int i) { return bank()[(size_t) i].name; }
const char* category(int i) { return bank()[(size_t) i].cat; }

void load(int index, float* out)
{
    for (int i = 0; i < synthp::NUM_PARAMS; ++i) out[i] = synthp::kParams[i].defV;
    if (index < 0 || index >= count()) return;
    for (const auto& kv : bank()[(size_t) index].v)
    {
        const int id = synthp::findParam(kv.first);
        if (id >= 0) out[id] = synthp::clampToParam(id, kv.second);
    }
}

int validate()
{
    int bad = 0;
    for (const auto& p : bank())
        for (const auto& kv : p.v)
            if (synthp::findParam(kv.first) < 0) { std::printf("unknown param id '%s' in preset '%s'\n", kv.first, p.name); ++bad; }
    return bad;
}
}
