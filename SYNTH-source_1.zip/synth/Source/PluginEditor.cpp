#include "PluginEditor.h"
#include "Presets.h"

using namespace ui;
using namespace synthp;

// ------------------------------------------------------------------ background
void SynthAudioProcessorEditor::Content::paint(juce::Graphics& g)
{
    const auto clip = g.getClipBounds();
    g.setGradientFill(juce::ColourGradient(juce::Colour(0xff0a0a14), (float) getWidth() * 0.5f, 0.0f, juce::Colour(0xff030306), (float) getWidth() * 0.5f, (float) getHeight(), false));
    g.fillRect(clip);
    // faint colour fog in the corners
    g.setGradientFill(juce::ColourGradient(col::violet.withAlpha(0.10f), 0.0f, 0.0f, juce::Colours::transparentBlack, 420.0f, 300.0f, true));
    g.fillRect(clip);
    g.setGradientFill(juce::ColourGradient(col::ice.withAlpha(0.07f), (float) getWidth(), (float) getHeight(), juce::Colours::transparentBlack, (float) getWidth() - 480.0f, (float) getHeight() - 320.0f, true));
    g.fillRect(clip);
    // grain
    if (noise.isValid()) { g.setTiledImageFill(noise, 0, 0, 1.0f); g.fillRect(clip); }
    // scanlines
    g.setColour(juce::Colours::black.withAlpha(0.22f));
    for (int y = clip.getY() - (clip.getY() % 3); y < clip.getBottom(); y += 3) g.fillRect(clip.getX(), y, clip.getWidth(), 1);

    // header
    auto head = juce::Rectangle<int>(0, 0, getWidth(), 56);
    g.setColour(col::panelEdge); g.fillRect(head.getX() + 10, 55, getWidth() - 20, 1);
    const juce::Font logo(juce::FontOptions(juce::Font::getDefaultMonospacedFontName(), 30.0f, juce::Font::bold).withKerningFactor(0.28f));
    g.setFont(logo);
    for (int i = 4; i >= 1; --i) { g.setColour(col::ice.withAlpha(0.05f * (float) (5 - i))); g.drawText("SYNTH", 16 - i, 8 - i, 200 + 2 * i, 38 + 2 * i, juce::Justification::centredLeft); }
    g.setColour(juce::Colours::white); g.drawText("SYNTH", 16, 8, 200, 38, juce::Justification::centredLeft);
    g.setColour(col::red); g.setFont(hudFont(9.0f, true));
    g.drawText("KAKE // CLOUD RAP DARK ENGINE", 18, 40, 260, 12, juce::Justification::centredLeft);
    g.setColour(col::textDim); g.setFont(hudFont(9.0f));
    g.drawText("VOICES " + juce::String(voices).paddedLeft('0', 2) + " / 08", getWidth() - 230, 6, 100, 12, juce::Justification::centredRight);
}

// ------------------------------------------------------------------ construction
SynthAudioProcessorEditor::SynthAudioProcessorEditor(SynthAudioProcessor& p) : AudioProcessorEditor(&p), proc(p)
{
    setLookAndFeel(&laf);
    setOpaque(true);
    setWantsKeyboardFocus(false);

    content.noise = juce::Image(juce::Image::ARGB, 96, 96, true);
    {
        juce::Random rnd(1234);
        for (int y = 0; y < 96; ++y) for (int x = 0; x < 96; ++x)
            content.noise.setPixelAt(x, y, juce::Colour::fromFloatRGBA(1.0f, 1.0f, 1.0f, rnd.nextFloat() * 0.035f));
    }
    addAndMakeVisible(content);
    content.setSize(kBaseW, kBaseH);
    buildUI();

    setResizable(true, true);
    setResizeLimits(kBaseW * 3 / 4, kBaseH * 3 / 4, kBaseW * 2, kBaseH * 2);
    if (auto* c = getConstrainer()) c->setFixedAspectRatio((double) kBaseW / (double) kBaseH);
    setSize(kBaseW, kBaseH);
    startTimerHz(10);
}

SynthAudioProcessorEditor::~SynthAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void SynthAudioProcessorEditor::parentHierarchyChanged()
{
    // software rendering: the most compatible path inside FL Studio's plugin window
    if (auto* peer = getPeer()) peer->setCurrentRenderingEngine(0);
}

void SynthAudioProcessorEditor::timerCallback()
{
    const int v = proc.voiceCount.load();
    if (v != lastVoices) { lastVoices = v; content.voices = v; content.repaint(0, 0, kBaseW, 14); }
    if (presetBox.getText() != proc.getCurrentPresetName() && !presetBox.isPopupActive())
        presetBox.setText(proc.getCurrentPresetName(), juce::dontSendNotification);
}

void SynthAudioProcessorEditor::buildUI()
{
    auto& apvts = proc.apvts;
    auto panel = [&](const char* title, juce::Colour c) -> Panel& { auto& p = make<Panel>(title, c); content.addAndMakeVisible(p); return p; };
    auto knob = [&](Panel& pn, int param, const char* label, int c, int r, juce::Colour acc, bool big = false, int span = 1) -> KnobControl&
    { auto& k = make<KnobControl>(apvts, param, label, acc, big); pn.place(&k, c, r, span); return k; };
    auto choice = [&](Panel& pn, int param, const char* label, int c, int r, int span = 1) { auto& k = make<ChoiceControl>(apvts, param, label); pn.place(&k, c, r, span); };
    auto toggle = [&](Panel& pn, int param, const char* label, int c, int r, juce::Colour acc) { auto& k = make<ToggleControl>(apvts, param, label, acc); pn.place(&k, c, r); };

    // ---- OSC 1 / 2
    for (int o = 0; o < 2; ++o)
    {
        auto& pn = panel(o == 0 ? "OSC 1" : "OSC 2", o == 0 ? col::ice : col::red);
        (o == 0 ? pOsc1 : pOsc2) = &pn;
        const int b = O1_TABLE + o * (O2_TABLE - O1_TABLE);
        const auto acc = o == 0 ? col::ice : col::red;
        pn.setGrid(4, 2);
        knob(pn, b + 0, "TABLE", 0, 0, acc); knob(pn, b + 1, "OCT", 1, 0, acc); knob(pn, b + 2, "SEMI", 2, 0, acc); knob(pn, b + 3, "FINE", 3, 0, acc);
        knob(pn, b + 4, "LEVEL", 0, 1, acc); knob(pn, b + 5, "UNISON", 1, 1, acc); knob(pn, b + 6, "DETUNE", 2, 1, acc); knob(pn, b + 7, "SPREAD", 3, 1, acc);
    }
    // ---- SUB / NOISE / FM
    {
        auto& pn = panel("SUB / NOISE / FM", col::violet); pSub = &pn; pn.setGrid(3, 2);
        knob(pn, SUB_LEVEL, "SUB", 0, 0, col::violet); choice(pn, SUB_OCT, "SUB OCT", 1, 0); choice(pn, SUB_WAVE, "SUB WAVE", 2, 0);
        knob(pn, NOISE_LEVEL, "NOISE", 0, 1, col::violet); knob(pn, FM_AMT, "FM", 1, 1, col::violet); knob(pn, RING_AMT, "RING", 2, 1, col::violet);
    }
    // ---- displays
    {
        auto& pn = panel("MONITOR", col::toxic); pDisp = &pn;
        wtView = &make<WavetableView>(proc); scopeView = &make<ScopeView>(proc); specView = &make<SpectrumView>(proc);
        pn.addAndMakeVisible(wtView); pn.addAndMakeVisible(scopeView); pn.addAndMakeVisible(specView);
    }
    // ---- filter
    {
        auto& pn = panel("FILTER", col::violet); pFilter = &pn; pn.setGrid(5, 2);
        choice(pn, F1_TYPE, "F1 TYPE", 0, 0); knob(pn, F1_CUT, "CUTOFF", 1, 0, col::violet); knob(pn, F1_RES, "RESO", 2, 0, col::violet);
        knob(pn, F1_DRIVE, "DRIVE", 3, 0, col::violet); knob(pn, F1_ENV, "ENV", 4, 0, col::violet);
        choice(pn, F2_MODE, "F2 MODE", 0, 1); knob(pn, F2_CUT, "F2 CUT", 1, 1, col::violet); knob(pn, F2_RES, "F2 RESO", 2, 1, col::violet);
        choice(pn, F2_TYPE, "F2 TYPE", 3, 1); knob(pn, F1_KEY, "KEYTRK", 4, 1, col::violet);
    }
    // ---- envelopes
    for (int e = 0; e < 2; ++e)
    {
        auto& pn = panel(e == 0 ? "AMP ENV" : "ENV 2", e == 0 ? col::ice : col::red); (e == 0 ? pAmp : pEnv2) = &pn; pn.setGrid(2, 2);
        const int b = e == 0 ? AMP_A : ENV2_A; const auto acc = e == 0 ? col::ice : col::red;
        knob(pn, b, "ATK", 0, 0, acc); knob(pn, b + 1, "DEC", 1, 0, acc); knob(pn, b + 2, "SUS", 0, 1, acc); knob(pn, b + 3, "REL", 1, 1, acc);
    }
    // ---- LFOs
    {
        auto& pn = panel("LFO 1 / LFO 2", col::toxic); pLfo = &pn; pn.setGrid(4, 2);
        for (int l = 0; l < 2; ++l)
        {
            const int b = l == 0 ? L1_SHAPE : L2_SHAPE;
            choice(pn, b, l == 0 ? "L1 SHAPE" : "L2 SHAPE", 0, l); knob(pn, b + 1, l == 0 ? "L1 RATE" : "L2 RATE", 1, l, col::toxic);
            toggle(pn, b + 2, l == 0 ? "L1 SYNC" : "L2 SYNC", 2, l, col::toxic); choice(pn, b + 3, l == 0 ? "L1 DIV" : "L2 DIV", 3, l);
        }
    }
    // ---- voice
    {
        auto& pn = panel("VOICE", col::ice); pVoice = &pn; pn.setGrid(2, 2);
        choice(pn, VOICE_MODE, "MODE", 0, 0); knob(pn, GLIDE, "GLIDE", 1, 0, col::ice);
        knob(pn, BEND_RANGE, "BEND", 0, 1, col::ice); knob(pn, DRIFT, "DRIFT", 1, 1, col::ice);
    }
    // ---- mod matrix
    {
        auto& pn = panel("MOD MATRIX  //  SOURCE > DEST > AMOUNT", col::red); pMod = &pn; pn.setGrid(2, 4);
        for (int s = 0; s < NUM_MOD_SLOTS; ++s) { auto& m = make<ModSlot>(apvts, s, col::red); pn.place(&m, s / 4, s % 4); }
    }
    // ---- macros
    {
        auto& pn = panel("MACROS", col::violet); pMacro = &pn; pn.setGrid(4, 1);
        knob(pn, MAC_HAZE, "HAZE", 0, 0, col::violet, true); knob(pn, MAC_GRIT, "GRIT", 1, 0, col::red, true);
        knob(pn, MAC_DRIFT, "DRIFT", 2, 0, col::ice, true); knob(pn, MAC_DARK, "DARK", 3, 0, col::toxic, true);
    }
    // ---- FX
    {
        auto& pn = panel("FX CHAIN  //  DIST > CRUSH > CHORUS > TAPE > DELAY > REVERB > MASTER", col::red); pFx = &pn;
        pn.setGrid(13, 2, 12);
        const auto c = col::red;
        pn.addGroup(0, 0, 3, "DISTORTION"); knob(pn, DIST_DRIVE, "DRIVE", 0, 0, c); choice(pn, DIST_TYPE, "TYPE", 1, 0); knob(pn, DIST_MIX, "MIX", 2, 0, c);
        pn.addGroup(0, 3, 3, "BITCRUSH"); knob(pn, CRUSH_BITS, "BITS", 3, 0, c); knob(pn, CRUSH_RATE, "RATE", 4, 0, c); knob(pn, CRUSH_MIX, "MIX", 5, 0, c);
        pn.addGroup(0, 6, 3, "CHORUS"); knob(pn, CHO_RATE, "RATE", 6, 0, col::violet); knob(pn, CHO_DEPTH, "DEPTH", 7, 0, col::violet); knob(pn, CHO_MIX, "MIX", 8, 0, col::violet);
        pn.addGroup(0, 9, 3, "TAPE"); knob(pn, TAPE_AMT, "WOW/SAT", 9, 0, col::violet); knob(pn, TAPE_TONE, "TONE", 10, 0, col::violet); knob(pn, TAPE_NOISE, "HISS", 11, 0, col::violet);
        pn.addGroup(1, 0, 5, "DELAY"); choice(pn, DLY_DIV, "DIV", 0, 1); knob(pn, DLY_TIME, "TIME", 1, 1, col::ice); knob(pn, DLY_FB, "FEEDBK", 2, 1, col::ice);
        knob(pn, DLY_TONE, "TONE", 3, 1, col::ice); knob(pn, DLY_MIX, "MIX", 4, 1, col::ice);
        pn.addGroup(1, 5, 6, "REVERB  +  SHIMMER"); knob(pn, REV_SIZE, "SIZE", 5, 1, col::ice); knob(pn, REV_DECAY, "DECAY", 6, 1, col::ice); knob(pn, REV_DAMP, "DAMP", 7, 1, col::ice);
        knob(pn, REV_PRE, "PRE", 8, 1, col::ice); knob(pn, REV_SHIM, "SHIMMER", 9, 1, col::toxic); knob(pn, REV_MIX, "MIX", 10, 1, col::ice);
        pn.addGroup(1, 11, 2, "MASTER"); knob(pn, UW_CUT, "UNDERWTR", 11, 1, col::toxic);
        masterKnob = &knob(pn, MASTER_VOL, "VOLUME", 12, 1, col::ice);
        pn.addGroup(0, 12, 1, "OUT"); widthKnob = &knob(pn, MASTER_WIDTH, "WIDTH", 12, 0, col::ice);
    }

    // ---- preset bar
    presetBox.setJustificationType(juce::Justification::centred);
    content.addAndMakeVisible(presetBox); content.addAndMakeVisible(prevBtn); content.addAndMakeVisible(nextBtn); content.addAndMakeVisible(saveBtn);
    rebuildPresetMenu();
    presetBox.setText(proc.getCurrentPresetName(), juce::dontSendNotification);
    presetBox.onChange = [this]
    {
        const int id = presetBox.getSelectedId();
        if (id >= 1 && id < 1000) proc.loadFactoryPreset(id - 1);
        else if (id >= 1000 && (size_t) (id - 1000) < userPresets.size()) proc.loadUserPreset(userPresets[(size_t) (id - 1000)]);
        presetBox.setText(proc.getCurrentPresetName(), juce::dontSendNotification);
    };
    auto step = [this](int dir)
    {
        const int n = presetBox.getNumItems();
        if (n == 0) return;
        int idx = presetBox.getSelectedItemIndex();
        for (int tries = 0; tries < n; ++tries)
        {
            idx = (idx + dir + n) % n;
            if (presetBox.getItemId(idx) != 0) break;
        }
        presetBox.setSelectedItemIndex(idx, juce::sendNotificationSync);
    };
    prevBtn.onClick = [step] { step(-1); };
    nextBtn.onClick = [step] { step(1); };
    saveBtn.onClick = [this] { promptSavePreset(); };
}

void SynthAudioProcessorEditor::rebuildPresetMenu()
{
    presetBox.clear(juce::dontSendNotification);
    juce::String lastCat;
    for (int i = 0; i < presets::count(); ++i)
    {
        if (lastCat != presets::category(i)) { lastCat = presets::category(i); presetBox.addSectionHeading(lastCat.toUpperCase()); }
        presetBox.addItem(presets::name(i), i + 1);
    }
    userPresets.clear();
    auto files = SynthAudioProcessor::getUserPresetDir().findChildFiles(juce::File::findFiles, false, "*.synthpreset");
    files.sort();
    if (!files.isEmpty()) presetBox.addSectionHeading("USER");
    for (int i = 0; i < files.size(); ++i) { userPresets.push_back(files[i]); presetBox.addItem(files[i].getFileNameWithoutExtension(), 1000 + i); }
}

void SynthAudioProcessorEditor::promptSavePreset()
{
    auto* w = new juce::AlertWindow("SAVE PRESET", "Name your patch:", juce::MessageBoxIconType::NoIcon, this);
    w->addTextEditor("name", proc.getCurrentPresetName(), "");
    w->addButton("SAVE", 1, juce::KeyPress(juce::KeyPress::returnKey));
    w->addButton("CANCEL", 0, juce::KeyPress(juce::KeyPress::escapeKey));
    juce::Component::SafePointer<SynthAudioProcessorEditor> safe(this);
    w->enterModalState(true, juce::ModalCallbackFunction::create([safe, w](int result)
    {
        if (result == 1 && safe != nullptr)
        {
            const auto name = w->getTextEditorContents("name");
            if (safe->proc.saveUserPreset(name)) { safe->rebuildPresetMenu(); safe->presetBox.setText(safe->proc.getCurrentPresetName(), juce::dontSendNotification); }
        }
    }), true);
}

// ------------------------------------------------------------------ layout (all in base 1180 x 780 units)
void SynthAudioProcessorEditor::layoutContent()
{
    const int M = 10, G = 6;
    // header controls
    presetBox.setBounds(kBaseW / 2 - 170, 14, 320, 26);
    prevBtn.setBounds(kBaseW / 2 - 208, 14, 32, 26);
    nextBtn.setBounds(kBaseW / 2 + 156, 14, 32, 26);
    saveBtn.setBounds(kBaseW / 2 + 194, 14, 56, 26);

    auto row = [&](int y, int h, std::vector<std::pair<ui::Panel*, float>> items)
    {
        float total = 0; for (auto& i : items) total += i.second;
        const float avail = (float) (kBaseW - 2 * M - G * ((int) items.size() - 1));
        float x = (float) M;
        for (auto& i : items) { const float w = avail * i.second / total; i.first->setBounds((int) x, y, (int) w, h); x += w + (float) G; }
    };
    row(62, 168, { { pOsc1, 2.9f }, { pOsc2, 2.9f }, { pSub, 2.3f }, { pDisp, 3.6f } });
    row(236, 168, { { pFilter, 3.8f }, { pAmp, 1.6f }, { pEnv2, 1.6f }, { pLfo, 3.2f }, { pVoice, 1.7f } });
    row(410, 176, { { pMod, 6.6f }, { pMacro, 4.0f } });
    pFx->setBounds(M, 592, kBaseW - 2 * M, 180);

    // monitor panel: wavetable + scope on top, spectrum below
    auto a = pDisp->contentArea().withTrimmedTop(0);
    const int topH = (int) ((float) a.getHeight() * 0.56f);
    auto top = a.removeFromTop(topH); a.removeFromTop(4);
    wtView->setBounds(top.removeFromLeft((int) ((float) top.getWidth() * 0.5f) - 2)); top.removeFromLeft(4);
    scopeView->setBounds(top); specView->setBounds(a);
}

void SynthAudioProcessorEditor::resized()
{
    content.setBounds(0, 0, kBaseW, kBaseH);
    content.setTransform(juce::AffineTransform::scale((float) getWidth() / (float) kBaseW));
    layoutContent();
}
