#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Presets.h"
#include "DSP/Wavetables.h"

using namespace synthp;

namespace
{
juce::String formatValue(const ParamDef& d, float v)
{
    const juce::String id(d.id);
    auto sec = [](float s) { return s < 1.0f ? juce::String(juce::roundToInt(s * 1000.0f)) + " ms" : juce::String(s, 2) + " s"; };
    if (id.endsWithIgnoreCase("_table")) return wt::name(juce::roundToInt(v * (float) (wt::NUM_TABLES - 1)));
    if (id.endsWith("_fine")) return juce::String(v, 0) + " ct";
    if (id.endsWith("_semi") || id == "bend_range") return juce::String(juce::roundToInt(v)) + " st";
    if (id.endsWith("_oct")) return juce::String(juce::roundToInt(v)) + " oct";
    if (id.endsWith("_uni")) return juce::String(juce::roundToInt(v)) + " voices";
    if (id == "crush_bits") return juce::String(juce::roundToInt(v)) + " bit";
    if (id == "crush_rate") return "1/" + juce::String(v, 1);
    if (id == "glide" || id == "amp_a" || id == "amp_d" || id == "amp_r" || id == "env2_a" || id == "env2_d" || id == "env2_r") return sec(v);
    if (id == "dly_time" || id == "rev_pre") return juce::String(juce::roundToInt(v)) + " ms";
    if (id.endsWith("_rate") && d.maxV <= 40.0f && id.startsWith("l")) return juce::String(v, 2) + " Hz";
    if (id == "cho_rate") return juce::String(v, 2) + " Hz";
    if (d.maxV >= 1000.0f) return v >= 1000.0f ? juce::String(v / 1000.0f, 2) + " kHz" : juce::String(juce::roundToInt(v)) + " Hz";
    if (d.minV >= -1.0f && d.maxV <= 2.0f) return juce::String(juce::roundToInt(v * 100.0f)) + " %";
    return juce::String(v, 2);
}

float parseValue(const ParamDef& d, const juce::String& t)
{
    float v = t.retainCharacters("-0123456789.").getFloatValue();
    const juce::String id(d.id);
    if (t.containsIgnoreCase("k") && d.maxV >= 1000.0f) v *= 1000.0f;
    else if (t.containsIgnoreCase("ms") && (id == "glide" || id.endsWith("_a") || id.endsWith("_d") || id.endsWith("_r"))) v *= 0.001f;
    else if (t.containsIgnoreCase("%")) v *= 0.01f;
    else if (id.endsWith("_table")) v = v; // typed as 0..1
    else if (d.minV >= -1.0f && d.maxV <= 2.0f && !id.endsWith("_table") && std::abs(v) > 2.0f) v *= 0.01f;
    return v;
}
}

juce::AudioProcessorValueTreeState::ParameterLayout SynthAudioProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    for (int i = 0; i < NUM_PARAMS; ++i)
    {
        const ParamDef& d = kParams[i];
        const juce::ParameterID pid { d.id, 1 };
        switch (d.type)
        {
            case PType::Float:
            {
                juce::NormalisableRange<float> range(d.minV, d.maxV, d.step, d.skew);
                auto attrs = juce::AudioParameterFloatAttributes()
                                 .withStringFromValueFunction([i](float v, int) { return formatValue(kParams[i], v); })
                                 .withValueFromStringFunction([i](const juce::String& t) { return parseValue(kParams[i], t); });
                layout.add(std::make_unique<juce::AudioParameterFloat>(pid, d.name, range, d.defV, attrs));
                break;
            }
            case PType::Choice:
            {
                juce::StringArray items; items.addTokens(d.choices, "|", "");
                layout.add(std::make_unique<juce::AudioParameterChoice>(pid, d.name, items, (int) d.defV));
                break;
            }
            case PType::Bool:
                layout.add(std::make_unique<juce::AudioParameterBool>(pid, d.name, d.defV > 0.5f));
                break;
        }
    }
    return layout;
}

SynthAudioProcessor::SynthAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "SYNTH_STATE", createLayout())
{
    wt::init();
    for (int i = 0; i < NUM_PARAMS; ++i)
        paramPtrs[(size_t) i] = apvts.getRawParameterValue(kParams[i].id);
}

bool SynthAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    const auto& out = l.getMainOutputChannelSet();
    return out == juce::AudioChannelSet::stereo() || out == juce::AudioChannelSet::mono();
}

void SynthAudioProcessor::prepareToPlay(double sr, int block)
{
    engine.prepare(sr, block);
    monoScratch.setSize(1, std::max(block, 1) + 64, false, true, true);
    scope.fill(0.0f);
}

void SynthAudioProcessor::handleMidi(const juce::MidiMessage& m)
{
    if (m.isNoteOn()) engine.noteOn(m.getNoteNumber(), m.getFloatVelocity());
    else if (m.isNoteOff()) engine.noteOff(m.getNoteNumber());
    else if (m.isPitchWheel()) engine.pitchBend(((float) m.getPitchWheelValue() - 8192.0f) / 8192.0f);
    else if (m.isChannelPressure()) engine.channelPressure((float) m.getChannelPressureValue() / 127.0f);
    else if (m.isAftertouch()) engine.channelPressure((float) m.getAfterTouchValue() / 127.0f);
    else if (m.isController()) engine.controller(m.getControllerNumber(), (float) m.getControllerValue() / 127.0f);
    else if (m.isAllNotesOff() || m.isAllSoundOff()) engine.controller(m.isAllSoundOff() ? 120 : 123, 1.0f);
}

void SynthAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    const int numCh = buffer.getNumChannels();
    if (n == 0 || numCh == 0) { midi.clear(); return; }

    for (int i = 0; i < NUM_PARAMS; ++i) paramValues[i] = paramPtrs[(size_t) i]->load();
    engine.setParams(paramValues);

    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
            if (auto bpm = pos->getBpm()) engine.setTransport(*bpm);

    float* L = buffer.getWritePointer(0);
    float* R = numCh > 1 ? buffer.getWritePointer(1) : nullptr;
    if (!R)
    {
        if (monoScratch.getNumSamples() < n) monoScratch.setSize(1, n, false, false, true);   // rare: host exceeded declared block size
        R = monoScratch.getWritePointer(0);
    }

    auto it = midi.begin();
    int pos = 0;
    while (pos < n)
    {
        while (it != midi.end() && (*it).samplePosition <= pos) { handleMidi((*it).getMessage()); ++it; }
        int end = std::min(n, pos + 32);
        if (it != midi.end()) end = std::min(end, std::max(pos + 1, (*it).samplePosition));
        engine.process(L + pos, R + pos, end - pos);
        pos = end;
    }
    while (it != midi.end()) { handleMidi((*it).getMessage()); ++it; }
    midi.clear();

    if (numCh > 2) for (int c = 2; c < numCh; ++c) buffer.clear(c, 0, n);
    if (numCh == 1) for (int i = 0; i < n; ++i) L[i] = 0.5f * (L[i] + R[i]);

    // scope tap (mono)
    int w = scopeWrite.load(std::memory_order_relaxed);
    for (int i = 0; i < n; ++i) { scope[(size_t) w] = 0.5f * (L[i] + (numCh > 1 ? R[i] : L[i])); w = (w + 1) & (kScopeSize - 1); }
    scopeWrite.store(w, std::memory_order_release);
    voiceCount.store(engine.activeVoices(), std::memory_order_relaxed);
}

void SynthAudioProcessor::copyScope(float* dest, int n) const
{
    n = std::min(n, kScopeSize);
    int w = scopeWrite.load(std::memory_order_acquire);
    for (int i = 0; i < n; ++i) dest[i] = scope[(size_t) ((w - n + i + kScopeSize) & (kScopeSize - 1))];
}

juce::AudioProcessorEditor* SynthAudioProcessor::createEditor() { return new SynthAudioProcessorEditor(*this); }

// ------------------------------------------------------------------ state + presets
void SynthAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    state.setProperty("presetName", currentPresetName, nullptr);
    state.setProperty("version", 1, nullptr);
    if (auto xml = state.createXml()) copyXmlToBinary(*xml, dest);
}

void SynthAudioProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(apvts.state.getType()))
        {
            auto vt = juce::ValueTree::fromXml(*xml);
            currentPresetName = vt.getProperty("presetName", "Init").toString();
            apvts.replaceState(vt);
        }
}

void SynthAudioProcessor::loadFactoryPreset(int index)
{
    if (index < 0 || index >= presets::count()) return;
    float p[NUM_PARAMS];
    presets::load(index, p);
    for (int i = 0; i < NUM_PARAMS; ++i)
        if (auto* prm = apvts.getParameter(kParams[i].id))
        {
            prm->beginChangeGesture();
            prm->setValueNotifyingHost(prm->convertTo0to1(p[i]));
            prm->endChangeGesture();
        }
    currentPresetName = presets::name(index);
}

juce::File SynthAudioProcessor::getUserPresetDir()
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("SYNTH").getChildFile("Presets");
}

bool SynthAudioProcessor::saveUserPreset(const juce::String& name)
{
    auto clean = juce::File::createLegalFileName(name.trim());
    if (clean.isEmpty()) return false;
    auto dir = getUserPresetDir();
    if (!dir.createDirectory().wasOk()) return false;
    auto state = apvts.copyState();
    state.setProperty("presetName", clean, nullptr);
    if (auto xml = state.createXml())
        if (xml->writeTo(dir.getChildFile(clean + ".synthpreset")))
        {
            currentPresetName = clean;
            return true;
        }
    return false;
}

bool SynthAudioProcessor::loadUserPreset(const juce::File& file)
{
    if (auto xml = juce::XmlDocument::parse(file))
        if (xml->hasTagName(apvts.state.getType()))
        {
            auto vt = juce::ValueTree::fromXml(*xml);
            apvts.replaceState(vt);
            currentPresetName = file.getFileNameWithoutExtension();
            return true;
        }
    return false;
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new SynthAudioProcessor(); }
