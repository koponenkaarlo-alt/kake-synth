// Renders the plugin editor to a PNG (headless) - used to review the UI without a DAW.
#include "../Source/PluginProcessor.h"
#include "../Source/PluginEditor.h"

int main(int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI init;
    const int preset = argc > 1 ? std::atoi(argv[1]) : 1;
    const juce::String out = argc > 2 ? argv[2] : "editor.png";

    SynthAudioProcessor proc;
    proc.setPlayConfigDetails(0, 2, 44100.0, 512);
    proc.prepareToPlay(44100.0, 512);
    proc.loadFactoryPreset(preset);

    juce::AudioBuffer<float> buf(2, 512);
    juce::MidiBuffer midi;
    midi.addEvent(juce::MidiMessage::noteOn(1, 48, 0.9f), 0);
    midi.addEvent(juce::MidiMessage::noteOn(1, 55, 0.8f), 0);
    midi.addEvent(juce::MidiMessage::noteOn(1, 63, 0.8f), 0);
    midi.addEvent(juce::MidiMessage::noteOn(1, 67, 0.8f), 0);
    for (int i = 0; i < 60; ++i) { proc.processBlock(buf, midi); midi.clear(); }

    std::unique_ptr<juce::AudioProcessorEditor> ed(proc.createEditor());
    ed->setSize(1180, 780);
    juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
    for (int i = 0; i < 8; ++i) { proc.processBlock(buf, midi); }
    juce::MessageManager::getInstance()->runDispatchLoopUntil(200);
    auto img = ed->createComponentSnapshot(ed->getLocalBounds(), true, 1.0f);
    juce::File f(out);
    f.deleteFile();
    juce::FileOutputStream os(f);
    juce::PNGImageFormat().writeImageToStream(img, os);
    std::printf("wrote %s (%dx%d)\n", out.toRawUTF8(), img.getWidth(), img.getHeight());
    ed.reset();
    return 0;
}
