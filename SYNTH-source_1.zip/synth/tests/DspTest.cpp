// Offline render tests for the DSP engine (no JUCE needed).
#include "../Source/DSP/Engine.h"
#include "../Source/DSP/Wavetables.h"
#include "../Source/Presets.h"
#include <cstdio>
#include <cmath>
#include <vector>
#include <chrono>
#include <string>
#include <cstdlib>

using namespace synthp;

struct Stats { float peak = 0, rms = 0; bool nan = false; double tail = 0; };

static int g_singleNote = -1;
static Stats render(const float* params, double sr, int block, bool chord, float seconds, std::vector<float>* outL = nullptr)
{
    synth::Engine e; e.prepare(sr, block); e.setParams(params); e.setTransport(140.0);
    const int total = (int) (sr * seconds);
    std::vector<float> L((size_t) total), R((size_t) total);
    int noteOffAt = (int) (sr * seconds * 0.6);
    int pos = 0; bool off = false;
    if (chord) { e.noteOn(48, 0.9f); e.noteOn(55, 0.8f); e.noteOn(60, 0.8f); e.noteOn(63, 0.7f); e.noteOn(67, 0.8f); e.noteOn(72, 0.7f); }
    else e.noteOn(g_singleNote >= 0 ? g_singleNote : 36, 1.0f);
    while (pos < total)
    {
        int n = std::min({ 32, total - pos, block });
        if (!off && pos >= noteOffAt) { off = true; for (int k : { 48, 55, 60, 63, 67, 72, 36, g_singleNote }) e.noteOff(k); }
        e.process(L.data() + pos, R.data() + pos, n);
        pos += n;
    }
    Stats s; double sum = 0;
    for (int i = 0; i < total; ++i)
    {
        if (!std::isfinite(L[(size_t) i]) || !std::isfinite(R[(size_t) i])) s.nan = true;
        s.peak = std::max({ s.peak, std::fabs(L[(size_t) i]), std::fabs(R[(size_t) i]) });
        sum += L[(size_t) i] * L[(size_t) i] + R[(size_t) i] * R[(size_t) i];
    }
    s.rms = (float) std::sqrt(sum / (2.0 * total));
    if (outL) *outL = L;
    return s;
}

int main(int argc, char** argv)
{
    int fails = 0;
    const bool verbose = std::getenv("SYNTH_VERBOSE") != nullptr;
    wt::init();
    if (presets::validate() != 0) ++fails;
    std::printf("%d factory presets\n", presets::count());
    // 1. wavetable sanity
    for (int t = 0; t < wt::NUM_TABLES; ++t)
    {
        const float* d = wt::table(t, 0); float pk = 0;
        for (int i = 0; i <= wt::SIZE; ++i) pk = std::max(pk, std::fabs(d[i]));
        if (!(pk > 0.05f && pk <= 1.0f)) { std::printf("FAIL wavetable %d peak %.3f\n", t, pk); ++fails; }
    }
    std::printf("wavetables OK (%d tables)\n", wt::NUM_TABLES);

    // 2. every factory preset x sample rates x buffer sizes
    const double rates[] = { 44100.0, 48000.0, 96000.0 };
    int count = 0; double worstCpu = 0; std::string worstName;
    for (int pi = 0; pi < presets::count(); ++pi)
    {
        float p[NUM_PARAMS]; presets::load(pi, p);
        for (double sr : rates)
        {
            for (bool chord : { true, false })
            {
                auto t0 = std::chrono::high_resolution_clock::now();
                Stats s = render(p, sr, 512, chord, 3.0f);
                double sec = std::chrono::duration<double>(std::chrono::high_resolution_clock::now() - t0).count();
                double cpu = sec / 3.0;
                if (cpu > worstCpu) { worstCpu = cpu; worstName = presets::name(pi); }
                const char* nm = presets::name(pi);
                if (verbose && sr == 44100.0) std::printf("  %-20s %-5s peak %.2f rms %.3f\n", nm, chord ? "chord" : "note", s.peak, s.rms);
                if (s.nan) { std::printf("FAIL %s @%.0f: NaN/Inf\n", nm, sr); ++fails; }
                if (s.peak > 1.0f) { std::printf("FAIL %s @%.0f: clipping %.3f\n", nm, sr, s.peak); ++fails; }
                if (s.rms < 0.003f) { std::printf("FAIL %s @%.0f: silent (rms %.5f)\n", nm, sr, s.rms); ++fails; }
                ++count;
            }
        }
    }
    std::printf("%d preset renders done, worst CPU load %.1f%% (%s, single core, offline)\n", count, worstCpu * 100.0, worstName.c_str());

    // 3. odd buffer sizes: tiny and huge should give the same-ish results and never crash
    {
        float p[NUM_PARAMS]; presets::load(0, p);
        for (int b : { 1, 7, 64, 333, 4096 }) { Stats s = render(p, 44100.0, b, true, 1.0f); if (s.nan || s.peak > 1.0f) { std::printf("FAIL block %d\n", b); ++fails; } }
        std::printf("buffer size sweep OK\n");
    }
    // 4. extreme parameter fuzz
    {
        unsigned st = 1; auto rnd = [&] { st = st * 1664525u + 1013904223u; return (st >> 8) / 16777216.0f; };
        for (int it = 0; it < 60; ++it)
        {
            float p[NUM_PARAMS];
            for (int i = 0; i < NUM_PARAMS; ++i)
            {
                const auto& d = kParams[i];
                float v = (rnd() < 0.3f) ? (rnd() < 0.5f ? d.minV : d.maxV) : d.minV + rnd() * (d.maxV - d.minV);
                if (d.step > 0) v = std::round(v / d.step) * d.step;
                p[i] = v;
            }
            Stats s = render(p, 44100.0, 256, true, 1.5f);
            if (s.nan || s.peak > 1.0f) { std::printf("FAIL fuzz %d nan=%d peak=%.3f\n", it, s.nan, s.peak); ++fails; }
        }
        std::printf("parameter fuzz OK (60 random extreme patches)\n");
    }
    // 4b. behaviour checks: release frees voices, pitch bend, sustain pedal, mono legato, no clicks on parameter sweeps
    {
        auto run = [](synth::Engine& e, int samples, std::vector<float>* out = nullptr)
        { std::vector<float> L(32), R(32); for (int i = 0; i < samples; i += 32) { e.process(L.data(), R.data(), 32); if (out) out->insert(out->end(), L.begin(), L.end()); } };
        auto freqOf = [](const std::vector<float>& x, double sr)
        { int z = 0; size_t first = 0, last = 0; for (size_t i = 1; i < x.size(); ++i) if (x[i - 1] < 0 && x[i] >= 0) { if (!z) first = i; last = i; ++z; } return z > 1 ? (z - 1) * sr / (double) (last - first) : 0.0; };
        float p[NUM_PARAMS]; presets::load(0, p);
        p[findParam("o1_uni")] = 1; p[findParam("f1_cut")] = 20000; p[findParam("f1_type")] = 0; p[findParam("drift")] = 0; p[findParam("amp_s")] = 1; p[findParam("amp_r")] = 0.2f;
        p[findParam("o1_table")] = 0.0f; // soft sine: clean zero crossings
        {   // release frees the voice
            synth::Engine e; e.prepare(44100, 512); e.setParams(p); e.noteOn(60, 1); run(e, 4410);
            if (e.activeVoices() != 1) { std::printf("FAIL voice not active\n"); ++fails; }
            e.noteOff(60); run(e, 44100 * 3);
            if (e.activeVoices() != 0) { std::printf("FAIL voice not freed after release\n"); ++fails; }
        }
        {   // pitch bend: +1 with range 2 st -> C4 * 2^(2/12)
            synth::Engine e; e.prepare(44100, 512); e.setParams(p); e.noteOn(69, 1); std::vector<float> a, b;
            run(e, 8820); run(e, 22050, &a); e.pitchBend(1.0f); run(e, 8820); run(e, 22050, &b);
            const double f0 = freqOf(a, 44100), f1 = freqOf(b, 44100);
            if (std::fabs(f0 - 440.0) > 3.0 || std::fabs(f1 - 440.0 * std::pow(2.0, 2.0 / 12.0)) > 4.0) { std::printf("FAIL pitch: %.1f -> %.1f Hz\n", f0, f1); ++fails; }
            else std::printf("pitch + bend OK (%.1f Hz -> %.1f Hz)\n", f0, f1);
        }
        {   // sustain pedal holds, releasing pedal frees
            synth::Engine e; e.prepare(44100, 512); e.setParams(p); e.controller(64, 1.0f); e.noteOn(60, 1); run(e, 2000); e.noteOff(60); run(e, 44100);
            if (e.activeVoices() != 1) { std::printf("FAIL sustain pedal did not hold\n"); ++fails; }
            e.controller(64, 0.0f); run(e, 44100 * 2);
            if (e.activeVoices() != 0) { std::printf("FAIL pedal release did not free voice\n"); ++fails; }
        }
        {   // mono legato with glide: second note slides
            float q[NUM_PARAMS]; std::copy(p, p + NUM_PARAMS, q); q[findParam("voice_mode")] = 2; q[findParam("glide")] = 0.3f;
            synth::Engine e; e.prepare(44100, 512); e.setParams(q); e.noteOn(57, 1); run(e, 22050);
            e.noteOn(69, 1); std::vector<float> early, late; run(e, 1500, &early); run(e, 22050); run(e, 22050, &late);
            const double fe = freqOf(early, 44100), fl = freqOf(late, 44100);
            if (!(fe > 230.0 && fe < 430.0) || std::fabs(fl - 440.0) > 4.0) { std::printf("FAIL glide: early %.1f late %.1f\n", fe, fl); ++fails; }
            else std::printf("legato glide OK (%.1f Hz early -> %.1f Hz)\n", fe, fl);
        }
        {   // cutoff sweep: no big discontinuities (zipper/click check)
            synth::Engine e; e.prepare(44100, 512); float q[NUM_PARAMS]; std::copy(p, p + NUM_PARAMS, q);
            q[findParam("o1_table")] = 4.0f / 11.0f; q[findParam("f1_type")] = 1; q[findParam("f1_cut")] = 200;
            e.setParams(q); e.noteOn(48, 1); std::vector<float> out; run(e, 4410, &out);
            for (int blk = 0; blk < 60; ++blk) { q[findParam("f1_cut")] = (blk & 1) ? 200.0f : 12000.0f; e.setParams(q); run(e, 512, &out); }
            float maxJump = 0; for (size_t i = 1; i < out.size(); ++i) maxJump = std::max(maxJump, std::fabs(out[i] - out[i - 1]));
            if (maxJump > 0.25f) { std::printf("FAIL parameter jump %.3f (zipper)\n", maxJump); ++fails; }
            else std::printf("cutoff step-automation smooth (max sample jump %.3f)\n", maxJump);
        }
    }
    // 5. dump a wav for listening if requested
    if (argc > 2)
    {
        int idx = std::atoi(argv[1]); float p[NUM_PARAMS]; presets::load(idx, p);
        if (argc > 3) g_singleNote = std::atoi(argv[3]);
        for (int a = 4; a < argc; ++a) { std::string kv = argv[a]; auto eq = kv.find('='); if (eq == std::string::npos) continue; int id = findParam(kv.substr(0, eq).c_str()); if (id >= 0) p[id] = std::atof(kv.c_str() + eq + 1); }
        std::vector<float> L; render(p, 44100.0, 512, g_singleNote < 0, 6.0f, &L);
        FILE* f = std::fopen(argv[2], "wb"); int sr = 44100, n = (int) L.size(), dl = n * 2;
        int riff = 36 + dl, fmt = 16, br = sr * 2; short af = 1, ch = 1, ba = 2, bps = 16;
        std::fwrite("RIFF", 1, 4, f); std::fwrite(&riff, 4, 1, f); std::fwrite("WAVEfmt ", 1, 8, f); std::fwrite(&fmt, 4, 1, f);
        std::fwrite(&af, 2, 1, f); std::fwrite(&ch, 2, 1, f); std::fwrite(&sr, 4, 1, f); std::fwrite(&br, 4, 1, f); std::fwrite(&ba, 2, 1, f); std::fwrite(&bps, 2, 1, f);
        std::fwrite("data", 1, 4, f); std::fwrite(&dl, 4, 1, f);
        for (float x : L) { short s = (short) (std::max(-1.0f, std::min(1.0f, x)) * 32767); std::fwrite(&s, 2, 1, f); }
        std::fclose(f);
    }
    std::printf(fails ? "\n%d FAILURES\n" : "\nALL TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
