# SYNTH - dark futuristic VST3 synth (cloud / underground rap)

A polyphonic wavetable synth built with C++17 + JUCE 8, targeting **Windows + FL Studio** (VST3).
The DSP core (`Source/DSP`, `Source/Params.*`, `Source/Presets.*`) has **no JUCE dependency**, so it can be tested offline.

## Build the plugin (Windows)

### Option A - no local setup: GitHub Actions
1. Create a new GitHub repository and push this folder (the `.gitignore` already skips build folders).
2. Open the **Actions** tab -> "Build SYNTH (Windows VST3)" -> wait for the green check.
3. Download the `SYNTH-VST3-Windows` artifact. Unzip it and run `install-vst3.ps1` (or copy `SYNTH.vst3` by hand).

### Option B - build locally
Requirements: Visual Studio 2022 Community ("Desktop development with C++"), CMake 3.22+, Git.

```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target SYNTH_VST3
```
JUCE 8.0.4 is downloaded automatically on the first configure (or drop a JUCE checkout into `./JUCE`).
The result is `build\SYNTH_artefacts\Release\VST3\SYNTH.vst3`.
Add `-DSYNTH_COPY_AFTER_BUILD=ON` (run the terminal as administrator) to copy it straight into `C:\Program Files\Common Files\VST3`.
The MSVC runtime is linked statically, so no Visual C++ redistributable is needed on the target PC.

### Install in FL Studio
1. Copy `SYNTH.vst3` (a folder) into `C:\Program Files\Common Files\VST3\`.
2. FL Studio: **Options > Manage plugins > Find installed plugins** (tick "Verify plugins" if it is not listed).
3. Add SYNTH from the plugin database (**Instrument > SYNTH**) or from the Channel Rack (+ > More plugins).

## Troubleshooting: plugin not showing up in FL Studio
- The folder must be exactly `...\VST3\SYNTH.vst3\Contents\x86_64-win\SYNTH.vst3`. Copying only the inner file also works, but keep the folder structure if you can.
- Use **Manage plugins > Find installed plugins** and make sure the `Common Files\VST3` folder is in the scan list (Plugin search paths).
- Only 64-bit FL Studio (21+) is supported. VST3 is not available in very old versions.
- Windows may block downloaded files: right-click the zip > Properties > **Unblock** before unzipping.
- If FL flags it as "not verified", re-run the scan with "Verify plugins" enabled and look at the FL log for the reason.

## Signal flow

```
MIDI -> 8 voices, each:
   OSC1 (wavetable, 1-7 unison) <-FM- OSC2 (wavetable, 1-7 unison)      ring-mod OSC1 x OSC2
   + SUB (sine/tri) + NOISE (tone-shaped)
   -> FILTER 1 (LP12 / Ladder24 / HP / BP / Notch, drive, key, env)  -> serial or parallel FILTER 2
   -> AMP ENV x velocity x mod-matrix amp -> pan
Sum of voices ->
   DISTORTION (soft / hard / fold) -> BITCRUSH -> CHORUS -> TAPE (wow/flutter, sat, hiss, crackle)
   -> PING-PONG DELAY (host tempo sync) -> REVERB (FDN, damping, pre-delay, shimmer)
   -> UNDERWATER low-pass -> MASTER volume + width -> safety limiter
```

Modulation: 2 LFOs (6 shapes, free or tempo-synced), Env 2, velocity, mod wheel, aftertouch, key track and per-note random,
routed through an 8-slot matrix to pitch, wavetable positions, cutoff, resonance, amp, pan, FM, drive and unison detune.

Macros (automatable, do not overwrite the underlying knobs): **HAZE** (reverb + chorus + tape + delay), **GRIT** (distortion + bitcrush + filter drive),
**DRIFT** (analog drift + tape wobble), **DARK** (filter cutoff, reverb damping, delay tone, underwater filter).

MIDI: notes (velocity), pitch bend (range param), mod wheel (CC1), channel/poly aftertouch, sustain pedal (CC64), all-notes-off.
Voice modes: Poly, Mono, Legato (glide for 808 slides).

## Adding wavetables
Edit `buildSpectrum()` in `Source/DSP/Wavetables.cpp`: each table is a list of harmonic amplitudes (and optional phases) that are turned into
11 band-limited mip levels automatically (alias-free at all pitches). Bump `NUM_TABLES` in `Wavetables.h`, `Params.h` generator and the
morph maths follows (the table knob always spans the full list). Names are in `kNames`.

## Adding presets
Presets are sparse lists of `{ "param_id", value }` overrides on top of the defaults - see `Source/Presets.cpp`.
User presets are saved as `%APPDATA%\SYNTH\Presets\*.synthpreset` from the SAVE button.

## Parameters
`tools/ParamsXMacro.h` holds the compact parameter definition; `tools/gen_params.cpp` generates the plain `Source/Params.h/.cpp` from it
(so MSVC never expands the macro table). After editing the table:

```
g++ -std=c++17 -I tools tools/gen_params.cpp tools/ParamsXMacro.cpp -o gen && ./gen Source
```
Parameter IDs (`o1_table`, `f1_cut`, ...) are used by FL Studio for automation and saved projects - never rename them once released.

## Tests
`SynthDspTest` (built by default) renders every factory preset at 44.1 / 48 / 96 kHz with chords and single notes and checks: no NaN/Inf,
no clipping, not silent; buffer sizes from 1 to 4096; 60 random extreme parameter sets; voice release, pitch bend, sustain pedal,
legato glide and click-free parameter steps. `pluginval --strictness-level 10` passes on the Linux build of the same source.

## License note
JUCE is AGPLv3 / commercial. Releasing SYNTH publicly or selling it needs either an open-source release under AGPL or a JUCE commercial licence.
Personal use in your own productions is fine.
