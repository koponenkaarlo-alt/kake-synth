#pragma once
// Plain C++ parameter table shared by the DSP engine, the JUCE wrapper, presets and tests.
namespace synthp
{
enum class PType : int { Float, Choice, Bool };

struct ParamDef
{
    const char* id;
    const char* name;
    PType type;
    float minV, maxV, defV, step, skew;
    const char* choices; // '|' separated for Choice params
    const char* group;
};

#define CH_MODSRC "Off|LFO 1|LFO 2|Env 2|Velocity|Mod Wheel|Aftertouch|Key Track|Random"
#define CH_MODDST "Off|Pitch|Osc1 Table|Osc2 Table|Cutoff|Resonance|Amp|Pan|FM|Drive|Uni Detune"
#define CH_LFOSHAPE "Sine|Tri|Saw|Square|S&H|Smooth"
#define CH_LFODIV "1/1|1/2|1/4|1/8|1/16|1/8T|1/16T|1/4D|1/8D"

#define OSC_PARAMS(X, n, dTable, dLevel, dUni) \
    X(O##n##_TABLE,  "o" #n "_table",  "Osc" #n " Table",  Float, 0, 1, dTable, 0, 1, "", "OSC" #n) \
    X(O##n##_OCT,    "o" #n "_oct",    "Osc" #n " Octave", Float, -3, 3, 0, 1, 1, "", "OSC" #n) \
    X(O##n##_SEMI,   "o" #n "_semi",   "Osc" #n " Semi",   Float, -12, 12, 0, 1, 1, "", "OSC" #n) \
    X(O##n##_FINE,   "o" #n "_fine",   "Osc" #n " Fine",   Float, -100, 100, 0, 0, 1, "", "OSC" #n) \
    X(O##n##_LEVEL,  "o" #n "_level",  "Osc" #n " Level",  Float, 0, 1, dLevel, 0, 1, "", "OSC" #n) \
    X(O##n##_UNI,    "o" #n "_uni",    "Osc" #n " Unison", Float, 1, 7, dUni, 1, 1, "", "OSC" #n) \
    X(O##n##_DETUNE, "o" #n "_detune", "Osc" #n " Detune", Float, 0, 1, 0.25, 0, 1, "", "OSC" #n) \
    X(O##n##_SPREAD, "o" #n "_spread", "Osc" #n " Spread", Float, 0, 1, 0.7, 0, 1, "", "OSC" #n)

#define LFO_PARAMS(X, n, dRate) \
    X(L##n##_SHAPE, "l" #n "_shape", "LFO" #n " Shape", Choice, 0, 5, 0, 1, 1, CH_LFOSHAPE, "LFO") \
    X(L##n##_RATE,  "l" #n "_rate",  "LFO" #n " Rate",  Float, 0.02f, 30, dRate, 0, 0.35f, "", "LFO") \
    X(L##n##_SYNC,  "l" #n "_sync",  "LFO" #n " Sync",  Bool, 0, 1, 0, 1, 1, "", "LFO") \
    X(L##n##_DIV,   "l" #n "_div",   "LFO" #n " Div",   Choice, 0, 8, 2, 1, 1, CH_LFODIV, "LFO")

#define MOD_SLOT(X, n) \
    X(M##n##_SRC, "m" #n "_src", "Mod" #n " Source", Choice, 0, 8, 0, 1, 1, CH_MODSRC, "MOD") \
    X(M##n##_DST, "m" #n "_dst", "Mod" #n " Dest",   Choice, 0, 10, 0, 1, 1, CH_MODDST, "MOD") \
    X(M##n##_AMT, "m" #n "_amt", "Mod" #n " Amount", Float, -1, 1, 0, 0, 1, "", "MOD")

#define ENV_PARAMS(X, P, pid, name, dA, dD, dS, dR, grp) \
    X(P##_A, pid "_a", name " Attack",  Float, 0.001f, 5, dA, 0, 0.3f, "", grp) \
    X(P##_D, pid "_d", name " Decay",   Float, 0.001f, 5, dD, 0, 0.3f, "", grp) \
    X(P##_S, pid "_s", name " Sustain", Float, 0, 1, dS, 0, 1, "", grp) \
    X(P##_R, pid "_r", name " Release", Float, 0.005f, 8, dR, 0, 0.3f, "", grp)

#define SYNTH_PARAMS(X) \
    OSC_PARAMS(X, 1, 0.0f, 0.8f, 3) \
    OSC_PARAMS(X, 2, 0.35f, 0.0f, 1) \
    X(SUB_LEVEL,   "sub_level",   "Sub Level",   Float, 0, 1, 0, 0, 1, "", "SUB") \
    X(SUB_OCT,     "sub_oct",     "Sub Octave",  Choice, 0, 1, 0, 1, 1, "-1|-2", "SUB") \
    X(SUB_WAVE,    "sub_wave",    "Sub Wave",    Choice, 0, 1, 0, 1, 1, "Sine|Tri", "SUB") \
    X(NOISE_LEVEL, "noise_level", "Noise Level", Float, 0, 1, 0, 0, 1, "", "SUB") \
    X(NOISE_TONE,  "noise_tone",  "Noise Tone",  Float, 0, 1, 0.5f, 0, 1, "", "SUB") \
    X(FM_AMT,      "fm_amt",      "FM Amount",   Float, 0, 1, 0, 0, 1, "", "SUB") \
    X(RING_AMT,    "ring_amt",    "Ring Mod",    Float, 0, 1, 0, 0, 1, "", "SUB") \
    X(F1_TYPE,  "f1_type",  "Filter1 Type",   Choice, 0, 4, 1, 1, 1, "LP12|Ladder24|HP|BP|Notch", "FILTER") \
    X(F1_CUT,   "f1_cut",   "Filter1 Cutoff", Float, 20, 20000, 6000, 0, 0.25f, "", "FILTER") \
    X(F1_RES,   "f1_res",   "Filter1 Reso",   Float, 0, 1, 0.15f, 0, 1, "", "FILTER") \
    X(F1_DRIVE, "f1_drive", "Filter1 Drive",  Float, 0, 1, 0, 0, 1, "", "FILTER") \
    X(F1_KEY,   "f1_key",   "Filter1 Key",    Float, 0, 1, 0.3f, 0, 1, "", "FILTER") \
    X(F1_ENV,   "f1_env",   "Filter1 Env",    Float, -1, 1, 0, 0, 1, "", "FILTER") \
    X(F2_MODE,  "f2_mode",  "Filter2 Mode",   Choice, 0, 2, 0, 1, 1, "Off|Serial|Parallel", "FILTER") \
    X(F2_TYPE,  "f2_type",  "Filter2 Type",   Choice, 0, 3, 1, 1, 1, "LP12|HP|BP|Notch", "FILTER") \
    X(F2_CUT,   "f2_cut",   "Filter2 Cutoff", Float, 20, 20000, 300, 0, 0.25f, "", "FILTER") \
    X(F2_RES,   "f2_res",   "Filter2 Reso",   Float, 0, 1, 0.1f, 0, 1, "", "FILTER") \
    ENV_PARAMS(X, AMP, "amp", "Amp", 0.01f, 0.4f, 0.7f, 0.35f, "AMP ENV") \
    ENV_PARAMS(X, ENV2, "env2", "Env2", 0.01f, 0.6f, 0.0f, 0.35f, "ENV 2") \
    LFO_PARAMS(X, 1, 2.0f) \
    LFO_PARAMS(X, 2, 0.3f) \
    MOD_SLOT(X, 1) MOD_SLOT(X, 2) MOD_SLOT(X, 3) MOD_SLOT(X, 4) \
    MOD_SLOT(X, 5) MOD_SLOT(X, 6) MOD_SLOT(X, 7) MOD_SLOT(X, 8) \
    X(VOICE_MODE, "voice_mode", "Voice Mode",  Choice, 0, 2, 0, 1, 1, "Poly|Mono|Legato", "VOICE") \
    X(GLIDE,      "glide",      "Glide",       Float, 0, 2, 0, 0, 0.4f, "", "VOICE") \
    X(BEND_RANGE, "bend_range", "Bend Range",  Float, 0, 24, 2, 1, 1, "", "VOICE") \
    X(DRIFT,      "drift",      "Analog Drift",Float, 0, 1, 0.2f, 0, 1, "", "VOICE") \
    X(MASTER_VOL, "master_vol", "Master",      Float, 0, 1, 0.7f, 0, 1, "", "MASTER") \
    X(MASTER_WIDTH,"master_width","Width",     Float, 0, 2, 1, 0, 1, "", "MASTER") \
    X(DIST_DRIVE, "dist_drive", "Dist Drive",  Float, 0, 1, 0.3f, 0, 1, "", "FX") \
    X(DIST_TYPE,  "dist_type",  "Dist Type",   Choice, 0, 2, 0, 1, 1, "Soft|Hard|Fold", "FX") \
    X(DIST_MIX,   "dist_mix",   "Dist Mix",    Float, 0, 1, 0, 0, 1, "", "FX") \
    X(CRUSH_BITS, "crush_bits", "Crush Bits",  Float, 3, 16, 16, 1, 1, "", "FX") \
    X(CRUSH_RATE, "crush_rate", "Crush Rate",  Float, 1, 40, 1, 0, 0.4f, "", "FX") \
    X(CRUSH_MIX,  "crush_mix",  "Crush Mix",   Float, 0, 1, 0, 0, 1, "", "FX") \
    X(CHO_RATE,   "cho_rate",   "Chorus Rate", Float, 0.05f, 5, 0.4f, 0, 0.5f, "", "FX") \
    X(CHO_DEPTH,  "cho_depth",  "Chorus Depth",Float, 0, 1, 0.5f, 0, 1, "", "FX") \
    X(CHO_MIX,    "cho_mix",    "Chorus Mix",  Float, 0, 1, 0, 0, 1, "", "FX") \
    X(TAPE_AMT,   "tape_amt",   "Tape Amount", Float, 0, 1, 0, 0, 1, "", "FX") \
    X(TAPE_TONE,  "tape_tone",  "Tape Tone",   Float, 500, 20000, 9000, 0, 0.3f, "", "FX") \
    X(TAPE_NOISE, "tape_noise", "Tape Noise",  Float, 0, 1, 0, 0, 1, "", "FX") \
    X(DLY_DIV,    "dly_div",    "Delay Div",   Choice, 0, 7, 3, 1, 1, "Free|1/4|1/4D|1/8|1/8D|1/8T|1/16|1/2", "FX") \
    X(DLY_TIME,   "dly_time",   "Delay Time",  Float, 10, 1500, 350, 0, 0.5f, "", "FX") \
    X(DLY_FB,     "dly_fb",     "Delay Feedback", Float, 0, 0.95f, 0.4f, 0, 1, "", "FX") \
    X(DLY_TONE,   "dly_tone",   "Delay Tone",  Float, 300, 12000, 3500, 0, 0.35f, "", "FX") \
    X(DLY_MIX,    "dly_mix",    "Delay Mix",   Float, 0, 1, 0, 0, 1, "", "FX") \
    X(REV_SIZE,   "rev_size",   "Reverb Size", Float, 0, 1, 0.7f, 0, 1, "", "FX") \
    X(REV_DECAY,  "rev_decay",  "Reverb Decay",Float, 0, 1, 0.6f, 0, 1, "", "FX") \
    X(REV_DAMP,   "rev_damp",   "Reverb Damp", Float, 0, 1, 0.5f, 0, 1, "", "FX") \
    X(REV_PRE,    "rev_pre",    "Reverb PreDelay", Float, 0, 200, 20, 0, 1, "", "FX") \
    X(REV_SHIM,   "rev_shim",   "Reverb Shimmer",  Float, 0, 1, 0, 0, 1, "", "FX") \
    X(REV_MIX,    "rev_mix",    "Reverb Mix",  Float, 0, 1, 0, 0, 1, "", "FX") \
    X(UW_CUT,     "uw_cut",     "Underwater",  Float, 200, 20000, 20000, 0, 0.3f, "", "FX") \
    X(MAC_HAZE,   "mac_haze",   "Haze",        Float, 0, 1, 0, 0, 1, "", "MACRO") \
    X(MAC_GRIT,   "mac_grit",   "Grit",        Float, 0, 1, 0, 0, 1, "", "MACRO") \
    X(MAC_DRIFT,  "mac_drift",  "Drift",       Float, 0, 1, 0, 0, 1, "", "MACRO") \
    X(MAC_DARK,   "mac_dark",   "Darkness",    Float, 0, 1, 0, 0, 1, "", "MACRO")

enum ParamIndex : int
{
#define X(e, id, nm, T, mn, mx, df, st, sk, ch, gr) e,
    SYNTH_PARAMS(X)
#undef X
    NUM_PARAMS
};

extern const ParamDef kParams[NUM_PARAMS];

int findParam(const char* id);                 // -1 if not found
float clampToParam(int index, float value);

constexpr int NUM_TABLES = 12;
constexpr int NUM_MOD_SLOTS = 8;

enum ModSource { SRC_OFF, SRC_LFO1, SRC_LFO2, SRC_ENV2, SRC_VEL, SRC_MODWHEEL, SRC_AFTERTOUCH, SRC_KEY, SRC_RANDOM, NUM_SRC };
enum ModDest { DST_OFF, DST_PITCH, DST_TABLE1, DST_TABLE2, DST_CUTOFF, DST_RES, DST_AMP, DST_PAN, DST_FM, DST_DRIVE, DST_DETUNE, NUM_DST };
} // namespace synthp
