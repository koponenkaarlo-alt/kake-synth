#include "ParamsXMacro.h"
#include <cstring>
#include <algorithm>

namespace synthp
{
const ParamDef kParams[NUM_PARAMS] = {
#define X(e, id, nm, T, mn, mx, df, st, sk, ch, gr) { id, nm, PType::T, (float) (mn), (float) (mx), (float) (df), (float) (st), (float) (sk), ch, gr },
    SYNTH_PARAMS(X)
#undef X
};

int findParam(const char* id)
{
    for (int i = 0; i < NUM_PARAMS; ++i)
        if (std::strcmp(kParams[i].id, id) == 0)
            return i;
    return -1;
}

float clampToParam(int i, float v)
{
    return std::min(kParams[i].maxV, std::max(kParams[i].minV, v));
}
} // namespace synthp
