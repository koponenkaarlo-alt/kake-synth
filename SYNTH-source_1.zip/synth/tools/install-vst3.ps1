# Installs SYNTH.vst3 into the standard system VST3 folder so FL Studio can find it.
# Right-click > "Run with PowerShell" (it asks for administrator rights itself).
$src = Join-Path $PSScriptRoot "SYNTH.vst3"
$dst = Join-Path $env:CommonProgramFiles "VST3"
if (-not (Test-Path $src)) { Write-Host "SYNTH.vst3 not found next to this script."; Read-Host "Press Enter"; exit 1 }
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""; exit }
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Remove-Item -Recurse -Force (Join-Path $dst "SYNTH.vst3") -ErrorAction SilentlyContinue
Copy-Item -Recurse -Force $src $dst
Write-Host "Installed to $dst\SYNTH.vst3"
Write-Host "In FL Studio: Options > Manage plugins > Find installed plugins (Verify plugins)."
Read-Host "Press Enter to close"
